import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  float,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const artists = mysqlTable("artists", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  bio: text("bio"),
  imageUrl: text("imageUrl"),
  genre: varchar("genre", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const albums = mysqlTable("albums", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  artistId: int("artistId").notNull(),
  coverUrl: text("coverUrl"),
  releaseYear: int("releaseYear"),
  genre: varchar("genre", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const songs = mysqlTable("songs", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  artistId: int("artistId").notNull(),
  albumId: int("albumId"),
  audioUrl: text("audioUrl").notNull().$type<string>(),
  coverUrl: text("coverUrl"),
  duration: int("duration").default(0),
  trackNumber: int("trackNumber").default(1),
  genre: varchar("genre", { length: 100 }),
  plays: int("plays").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const playlists = mysqlTable("playlists", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  coverUrl: text("coverUrl"),
  userId: int("userId").notNull(),
  isPublic: boolean("isPublic").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const playlistSongs = mysqlTable("playlist_songs", {
  id: int("id").autoincrement().primaryKey(),
  playlistId: int("playlistId").notNull(),
  songId: int("songId").notNull(),
  position: int("position").default(0),
  addedAt: timestamp("addedAt").defaultNow().notNull(),
});

export const userLibrary = mysqlTable("user_library", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  songId: int("songId"),
  albumId: int("albumId"),
  artistId: int("artistId"),
  type: mysqlEnum("type", ["song", "album", "artist"]).notNull(),
  savedAt: timestamp("savedAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Artist = typeof artists.$inferSelect;
export type Album = typeof albums.$inferSelect;
export type Song = typeof songs.$inferSelect;
export type Playlist = typeof playlists.$inferSelect;
export type PlaylistSong = typeof playlistSongs.$inferSelect;
export type UserLibraryItem = typeof userLibrary.$inferSelect;
