import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock de base de datos para tests
vi.mock("./db", () => ({
  getAllArtists: vi.fn().mockResolvedValue([
    { id: 1, name: "Luna Azul", bio: "Artista de pop", imageUrl: null, genre: "Pop", createdAt: new Date() },
  ]),
  getArtistById: vi.fn().mockResolvedValue(
    { id: 1, name: "Luna Azul", bio: "Artista de pop", imageUrl: null, genre: "Pop", createdAt: new Date() }
  ),
  getArtistAlbums: vi.fn().mockResolvedValue([]),
  getArtistSongs: vi.fn().mockResolvedValue([]),
  createArtist: vi.fn().mockResolvedValue({ insertId: 2 }),
  getAllAlbums: vi.fn().mockResolvedValue([]),
  getAlbumById: vi.fn().mockResolvedValue(undefined),
  getAlbumSongs: vi.fn().mockResolvedValue([]),
  createAlbum: vi.fn().mockResolvedValue({ insertId: 1 }),
  getAllSongs: vi.fn().mockResolvedValue([
    { id: 1, title: "Amanecer", artistId: 1, albumId: null, audioUrl: "https://example.com/song.mp3", coverUrl: null, duration: 210, plays: 100, createdAt: new Date() },
  ]),
  getSongById: vi.fn().mockResolvedValue(
    { id: 1, title: "Amanecer", artistId: 1, albumId: null, audioUrl: "https://example.com/song.mp3", coverUrl: null, duration: 210, plays: 100, createdAt: new Date() }
  ),
  getRecentSongs: vi.fn().mockResolvedValue([]),
  incrementSongPlays: vi.fn().mockResolvedValue(undefined),
  createSong: vi.fn().mockResolvedValue({ insertId: 1 }),
  searchAll: vi.fn().mockResolvedValue({ songs: [], artists: [], albums: [] }),
  getUserPlaylists: vi.fn().mockResolvedValue([]),
  getPlaylistById: vi.fn().mockResolvedValue(undefined),
  getPlaylistSongs: vi.fn().mockResolvedValue([]),
  createPlaylist: vi.fn().mockResolvedValue({ insertId: 1 }),
  updatePlaylist: vi.fn().mockResolvedValue(undefined),
  deletePlaylist: vi.fn().mockResolvedValue(undefined),
  addSongToPlaylist: vi.fn().mockResolvedValue(undefined),
  removeSongFromPlaylist: vi.fn().mockResolvedValue(undefined),
  getUserLibrary: vi.fn().mockResolvedValue({ songs: [], albums: [], artists: [] }),
  toggleLibraryItem: vi.fn().mockResolvedValue({ saved: true }),
  isInLibrary: vi.fn().mockResolvedValue(false),
  seedDatabase: vi.fn().mockResolvedValue({ message: "Seeded" }),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ key: "test-key", url: "/manus-storage/test-key" }),
}));

function createPublicCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createAuthCtx(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("artists router", () => {
  it("list devuelve lista de artistas", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.artists.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("name");
  });

  it("byId devuelve artista por ID", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.artists.byId({ id: 1 });
    expect(result).toBeDefined();
    expect(result?.name).toBe("Luna Azul");
  });
});

describe("songs router", () => {
  it("list devuelve canciones", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.songs.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]).toHaveProperty("title");
    expect(result[0]).toHaveProperty("audioUrl");
  });

  it("play incrementa reproducciones", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(caller.songs.play({ id: 1 })).resolves.not.toThrow();
  });
});

describe("search router", () => {
  it("query devuelve estructura correcta", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.search.query({ q: "luna" });
    expect(result).toHaveProperty("songs");
    expect(result).toHaveProperty("artists");
    expect(result).toHaveProperty("albums");
  });
});

describe("playlists router (autenticado)", () => {
  it("myPlaylists devuelve playlists del usuario", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.playlists.myPlaylists();
    expect(Array.isArray(result)).toBe(true);
  });

  it("create crea una playlist", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    await expect(caller.playlists.create({ name: "Mi Playlist Test" })).resolves.not.toThrow();
  });
});

describe("library router (autenticado)", () => {
  it("get devuelve biblioteca del usuario", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.library.get();
    expect(result).toHaveProperty("songs");
    expect(result).toHaveProperty("albums");
    expect(result).toHaveProperty("artists");
  });

  it("toggle guarda un ítem en la biblioteca", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.library.toggle({ type: "song", itemId: 1 });
    expect(result).toHaveProperty("saved");
  });

  it("check verifica si un ítem está guardado", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.library.check({ type: "song", itemId: 1 });
    expect(typeof result).toBe("boolean");
  });
});

describe("auth router", () => {
  it("me devuelve null sin autenticación", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("me devuelve usuario autenticado", async () => {
    const caller = appRouter.createCaller(createAuthCtx());
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Test User");
  });

  it("logout limpia la cookie de sesión", async () => {
    const ctx = createAuthCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});
