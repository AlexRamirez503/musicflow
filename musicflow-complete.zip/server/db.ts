import { eq, like, or, desc, and, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users, artists, albums, songs, playlists, playlistSongs, userLibrary,
  InsertUser, Artist, Album, Song, Playlist,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ── Users ──────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ── Artists ────────────────────────────────────────────────────────────────

export async function getAllArtists() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(artists).orderBy(artists.name);
}

export async function getArtistById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(artists).where(eq(artists.id, id)).limit(1);
  return result[0];
}

export async function getArtistAlbums(artistId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(albums).where(eq(albums.artistId, artistId)).orderBy(desc(albums.releaseYear));
}

export async function getArtistSongs(artistId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(songs).where(eq(songs.artistId, artistId)).orderBy(desc(songs.plays)).limit(10);
}

export async function createArtist(data: { name: string; bio?: string; imageUrl?: string; genre?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(artists).values(data);
  return result;
}

// ── Albums ─────────────────────────────────────────────────────────────────

export async function getAllAlbums() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(albums).orderBy(desc(albums.createdAt));
}

export async function getAlbumById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(albums).where(eq(albums.id, id)).limit(1);
  return result[0];
}

export async function getAlbumSongs(albumId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(songs).where(eq(songs.albumId, albumId)).orderBy(songs.trackNumber);
}

export async function createAlbum(data: { title: string; artistId: number; coverUrl?: string; releaseYear?: number; genre?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(albums).values(data);
}

// ── Songs ──────────────────────────────────────────────────────────────────

export async function getAllSongs(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(songs).orderBy(desc(songs.plays)).limit(limit);
}

export async function getSongById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(songs).where(eq(songs.id, id)).limit(1);
  return result[0];
}

export async function getRecentSongs(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(songs).orderBy(desc(songs.createdAt)).limit(limit);
}

export async function incrementSongPlays(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(songs).set({ plays: sql`${songs.plays} + 1` }).where(eq(songs.id, id));
}

export async function createSong(data: {
  title: string; artistId: number; albumId?: number;
  audioUrl: string; coverUrl?: string; duration?: number;
  trackNumber?: number; genre?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.insert(songs).values(data);
}

// ── Search ─────────────────────────────────────────────────────────────────

export async function searchAll(query: string) {
  const db = await getDb();
  if (!db) return { songs: [], artists: [], albums: [] };
  const q = `%${query}%`;
  const [foundSongs, foundArtists, foundAlbums] = await Promise.all([
    db.select().from(songs).where(like(songs.title, q)).limit(10),
    db.select().from(artists).where(like(artists.name, q)).limit(10),
    db.select().from(albums).where(like(albums.title, q)).limit(10),
  ]);
  return { songs: foundSongs, artists: foundArtists, albums: foundAlbums };
}

// ── Playlists ──────────────────────────────────────────────────────────────

export async function getUserPlaylists(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(playlists).where(eq(playlists.userId, userId)).orderBy(desc(playlists.updatedAt));
}

export async function getPlaylistById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(playlists).where(eq(playlists.id, id)).limit(1);
  return result[0];
}

export async function getPlaylistSongs(playlistId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ ps: playlistSongs, song: songs })
    .from(playlistSongs)
    .innerJoin(songs, eq(playlistSongs.songId, songs.id))
    .where(eq(playlistSongs.playlistId, playlistId))
    .orderBy(playlistSongs.position);
  return rows.map((r) => ({ ...r.song, position: r.ps.position }));
}

export async function createPlaylist(data: { name: string; description?: string; coverUrl?: string; userId: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(playlists).values({ ...data, isPublic: false });
  return result;
}

export async function updatePlaylist(id: number, data: { name?: string; description?: string; coverUrl?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.update(playlists).set(data).where(eq(playlists.id, id));
}

export async function deletePlaylist(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(playlistSongs).where(eq(playlistSongs.playlistId, id));
  return db.delete(playlists).where(eq(playlists.id, id));
}

export async function addSongToPlaylist(playlistId: number, songId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db
    .select()
    .from(playlistSongs)
    .where(and(eq(playlistSongs.playlistId, playlistId), eq(playlistSongs.songId, songId)))
    .limit(1);
  if (existing.length > 0) return;
  const count = await db.select({ c: sql<number>`count(*)` }).from(playlistSongs).where(eq(playlistSongs.playlistId, playlistId));
  const position = Number(count[0]?.c ?? 0);
  return db.insert(playlistSongs).values({ playlistId, songId, position });
}

export async function removeSongFromPlaylist(playlistId: number, songId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  return db.delete(playlistSongs).where(and(eq(playlistSongs.playlistId, playlistId), eq(playlistSongs.songId, songId)));
}

// ── User Library ───────────────────────────────────────────────────────────

export async function getUserLibrary(userId: number) {
  const db = await getDb();
  if (!db) return { songs: [], albums: [], artists: [] };
  const items = await db.select().from(userLibrary).where(eq(userLibrary.userId, userId));
  const savedSongIds = items.filter((i) => i.type === "song" && i.songId).map((i) => i.songId!);
  const savedAlbumIds = items.filter((i) => i.type === "album" && i.albumId).map((i) => i.albumId!);
  const savedArtistIds = items.filter((i) => i.type === "artist" && i.artistId).map((i) => i.artistId!);

  const [savedSongs, savedAlbums, savedArtists] = await Promise.all([
    savedSongIds.length > 0 ? db.select().from(songs).where(sql`${songs.id} IN (${savedSongIds.join(",")})`) : [],
    savedAlbumIds.length > 0 ? db.select().from(albums).where(sql`${albums.id} IN (${savedAlbumIds.join(",")})`) : [],
    savedArtistIds.length > 0 ? db.select().from(artists).where(sql`${artists.id} IN (${savedArtistIds.join(",")})`) : [],
  ]);
  return { songs: savedSongs, albums: savedAlbums, artists: savedArtists };
}

export async function toggleLibraryItem(userId: number, type: "song" | "album" | "artist", itemId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const field = type === "song" ? userLibrary.songId : type === "album" ? userLibrary.albumId : userLibrary.artistId;
  const existing = await db
    .select()
    .from(userLibrary)
    .where(and(eq(userLibrary.userId, userId), eq(userLibrary.type, type), eq(field, itemId)))
    .limit(1);

  if (existing.length > 0) {
    await db.delete(userLibrary).where(eq(userLibrary.id, existing[0].id));
    return { saved: false };
  } else {
    const values: any = { userId, type };
    if (type === "song") values.songId = itemId;
    if (type === "album") values.albumId = itemId;
    if (type === "artist") values.artistId = itemId;
    await db.insert(userLibrary).values(values);
    return { saved: true };
  }
}

export async function isInLibrary(userId: number, type: "song" | "album" | "artist", itemId: number) {
  const db = await getDb();
  if (!db) return false;
  const field = type === "song" ? userLibrary.songId : type === "album" ? userLibrary.albumId : userLibrary.artistId;
  const result = await db
    .select()
    .from(userLibrary)
    .where(and(eq(userLibrary.userId, userId), eq(userLibrary.type, type), eq(field, itemId)))
    .limit(1);
  return result.length > 0;
}

// ── Seed ───────────────────────────────────────────────────────────────────

export async function seedDatabase() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const existingArtists = await db.select().from(artists).limit(1);
  if (existingArtists.length > 0) return { message: "Database already seeded" };

  // Artists
  await db.insert(artists).values([
    { name: "Luna Azul", bio: "Banda de pop latino con influencias electrónicas.", imageUrl: "https://picsum.photos/seed/artist1/400/400", genre: "Pop Latino" },
    { name: "El Maestro", bio: "Artista de reggaeton y trap urbano.", imageUrl: "https://picsum.photos/seed/artist2/400/400", genre: "Reggaeton" },
    { name: "Valeria Cruz", bio: "Cantautora de baladas y pop acústico.", imageUrl: "https://picsum.photos/seed/artist3/400/400", genre: "Pop Acústico" },
    { name: "Noche Eterna", bio: "Grupo de rock alternativo latinoamericano.", imageUrl: "https://picsum.photos/seed/artist4/400/400", genre: "Rock Alternativo" },
    { name: "DJ Cosmos", bio: "Productor de música electrónica y house.", imageUrl: "https://picsum.photos/seed/artist5/400/400", genre: "Electrónica" },
  ]);

  const artistRows = await db.select().from(artists);
  const a = Object.fromEntries(artistRows.map((ar) => [ar.name, ar.id]));

  // Albums
  await db.insert(albums).values([
    { title: "Cielo Infinito", artistId: a["Luna Azul"], coverUrl: "https://picsum.photos/seed/album1/400/400", releaseYear: 2023, genre: "Pop Latino" },
    { title: "Ritmo Urbano", artistId: a["El Maestro"], coverUrl: "https://picsum.photos/seed/album2/400/400", releaseYear: 2023, genre: "Reggaeton" },
    { title: "Alma Desnuda", artistId: a["Valeria Cruz"], coverUrl: "https://picsum.photos/seed/album3/400/400", releaseYear: 2022, genre: "Pop Acústico" },
    { title: "Sombras", artistId: a["Noche Eterna"], coverUrl: "https://picsum.photos/seed/album4/400/400", releaseYear: 2022, genre: "Rock Alternativo" },
    { title: "Galaxia", artistId: a["DJ Cosmos"], coverUrl: "https://picsum.photos/seed/album5/400/400", releaseYear: 2024, genre: "Electrónica" },
  ]);

  const albumRows = await db.select().from(albums);
  const al = Object.fromEntries(albumRows.map((alb) => [alb.title, alb.id]));

  // Songs — audio de muestra libre de derechos (archive.org)
  const sampleAudio = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";
  const sampleAudio2 = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3";
  const sampleAudio3 = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3";

  await db.insert(songs).values([
    // Luna Azul - Cielo Infinito
    { title: "Amanecer", artistId: a["Luna Azul"], albumId: al["Cielo Infinito"], audioUrl: sampleAudio, coverUrl: "https://picsum.photos/seed/song1/400/400", duration: 210, trackNumber: 1, genre: "Pop Latino", plays: 1520 },
    { title: "Volar Contigo", artistId: a["Luna Azul"], albumId: al["Cielo Infinito"], audioUrl: sampleAudio2, coverUrl: "https://picsum.photos/seed/song2/400/400", duration: 195, trackNumber: 2, genre: "Pop Latino", plays: 980 },
    { title: "Lluvia de Estrellas", artistId: a["Luna Azul"], albumId: al["Cielo Infinito"], audioUrl: sampleAudio3, coverUrl: "https://picsum.photos/seed/song3/400/400", duration: 230, trackNumber: 3, genre: "Pop Latino", plays: 750 },
    // El Maestro - Ritmo Urbano
    { title: "La Calle Habla", artistId: a["El Maestro"], albumId: al["Ritmo Urbano"], audioUrl: sampleAudio, coverUrl: "https://picsum.photos/seed/song4/400/400", duration: 185, trackNumber: 1, genre: "Reggaeton", plays: 3200 },
    { title: "Noche de Fuego", artistId: a["El Maestro"], albumId: al["Ritmo Urbano"], audioUrl: sampleAudio2, coverUrl: "https://picsum.photos/seed/song5/400/400", duration: 200, trackNumber: 2, genre: "Reggaeton", plays: 2800 },
    { title: "Sin Miedo", artistId: a["El Maestro"], albumId: al["Ritmo Urbano"], audioUrl: sampleAudio3, coverUrl: "https://picsum.photos/seed/song6/400/400", duration: 215, trackNumber: 3, genre: "Reggaeton", plays: 1900 },
    // Valeria Cruz - Alma Desnuda
    { title: "Corazón Roto", artistId: a["Valeria Cruz"], albumId: al["Alma Desnuda"], audioUrl: sampleAudio, coverUrl: "https://picsum.photos/seed/song7/400/400", duration: 240, trackNumber: 1, genre: "Pop Acústico", plays: 4100 },
    { title: "Silencio", artistId: a["Valeria Cruz"], albumId: al["Alma Desnuda"], audioUrl: sampleAudio2, coverUrl: "https://picsum.photos/seed/song8/400/400", duration: 220, trackNumber: 2, genre: "Pop Acústico", plays: 3300 },
    // Noche Eterna - Sombras
    { title: "Oscuridad", artistId: a["Noche Eterna"], albumId: al["Sombras"], audioUrl: sampleAudio3, coverUrl: "https://picsum.photos/seed/song9/400/400", duration: 265, trackNumber: 1, genre: "Rock Alternativo", plays: 2100 },
    { title: "Tormenta Interior", artistId: a["Noche Eterna"], albumId: al["Sombras"], audioUrl: sampleAudio, coverUrl: "https://picsum.photos/seed/song10/400/400", duration: 250, trackNumber: 2, genre: "Rock Alternativo", plays: 1700 },
    // DJ Cosmos - Galaxia
    { title: "Nebulosa", artistId: a["DJ Cosmos"], albumId: al["Galaxia"], audioUrl: sampleAudio2, coverUrl: "https://picsum.photos/seed/song11/400/400", duration: 310, trackNumber: 1, genre: "Electrónica", plays: 5600 },
    { title: "Órbita", artistId: a["DJ Cosmos"], albumId: al["Galaxia"], audioUrl: sampleAudio3, coverUrl: "https://picsum.photos/seed/song12/400/400", duration: 290, trackNumber: 2, genre: "Electrónica", plays: 4800 },
  ]);

  return { message: "Database seeded successfully" };
}
