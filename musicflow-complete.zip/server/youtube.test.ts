import { describe, expect, it } from "vitest";
import {
  searchYouTubeTracks,
  getYouTubeByGenre,
  getPopularLatinMusic,
  getWorshipMusic,
  getTrendingMusic,
  getArtistTracks,
  FEATURED_ARTISTS,
  GENRES,
  cleanTitle,
} from "./youtube";

// Export cleanTitle for testing by making it accessible
// We test the module's public API

describe("YouTube integration", () => {
  it("should have featured artists for all categories", () => {
    expect(FEATURED_ARTISTS.alabanza).toBeDefined();
    expect(FEATURED_ARTISTS.alabanza.length).toBeGreaterThan(0);
    expect(FEATURED_ARTISTS.alabanza).toContain("Jesús Adrián Romero");

    expect(FEATURED_ARTISTS.reggaeton).toBeDefined();
    expect(FEATURED_ARTISTS.reggaeton).toContain("Bad Bunny");

    expect(FEATURED_ARTISTS.mexico).toBeDefined();
    expect(FEATURED_ARTISTS.mexico).toContain("Christian Nodal");

    expect(FEATURED_ARTISTS.puertoRico).toBeDefined();
    expect(FEATURED_ARTISTS.puertoRico).toContain("Daddy Yankee");

    expect(FEATURED_ARTISTS.popLatino).toBeDefined();
    expect(FEATURED_ARTISTS.popLatino).toContain("Shakira");
  });

  it("should have genres with required properties", () => {
    expect(GENRES.length).toBeGreaterThan(0);
    for (const genre of GENRES) {
      expect(genre).toHaveProperty("id");
      expect(genre).toHaveProperty("name");
      expect(genre).toHaveProperty("color");
      expect(genre).toHaveProperty("icon");
      expect(genre.id).toBeTruthy();
      expect(genre.name).toBeTruthy();
    }
  });

  it("should include alabanza genre", () => {
    const alabanza = GENRES.find((g) => g.id === "alabanza");
    expect(alabanza).toBeDefined();
    expect(alabanza?.name).toBe("Alabanza y Adoración");
  });

  it("should include reggaeton genre", () => {
    const reggaeton = GENRES.find((g) => g.id === "reggaeton");
    expect(reggaeton).toBeDefined();
    expect(reggaeton?.name).toBe("Reggaeton");
  });

  it("should search YouTube tracks and return results", async () => {
    const tracks = await searchYouTubeTracks("Bad Bunny");
    expect(Array.isArray(tracks)).toBe(true);
    // API may return results or empty depending on availability
    if (tracks.length > 0) {
      const track = tracks[0];
      expect(track).toHaveProperty("id");
      expect(track).toHaveProperty("videoId");
      expect(track).toHaveProperty("title");
      expect(track).toHaveProperty("artist");
      expect(track).toHaveProperty("thumbnail");
      expect(track.source).toBe("youtube");
      expect(track.id).toMatch(/^yt-/);
    }
  }, 15000);

  it("should get tracks by genre", async () => {
    const tracks = await getYouTubeByGenre("reggaeton");
    expect(Array.isArray(tracks)).toBe(true);
  }, 15000);

  it("should get popular latin music", async () => {
    const tracks = await getPopularLatinMusic();
    expect(Array.isArray(tracks)).toBe(true);
  }, 15000);

  it("should get worship music", async () => {
    const tracks = await getWorshipMusic();
    expect(Array.isArray(tracks)).toBe(true);
  }, 15000);

  it("should get artist tracks", async () => {
    const tracks = await getArtistTracks("Jesús Adrián Romero");
    expect(Array.isArray(tracks)).toBe(true);
  }, 15000);

  it("should get artist tracks for Bad Bunny with valid structure", async () => {
    const tracks = await getArtistTracks("Bad Bunny");
    expect(Array.isArray(tracks)).toBe(true);
    if (tracks.length > 0) {
      const track = tracks[0];
      expect(track.source).toBe("youtube");
      expect(track.id).toMatch(/^yt-/);
      expect(track.videoId).toBeTruthy();
      expect(track.thumbnailLarge).toBeTruthy();
    }
  }, 15000);

  it("should return tracks with thumbnailLarge for artist profile hero image", async () => {
    const tracks = await getArtistTracks("Shakira");
    expect(Array.isArray(tracks)).toBe(true);
    if (tracks.length > 0) {
      // Every track should have a thumbnailLarge for the hero/avatar
      for (const track of tracks) {
        expect(track.thumbnailLarge).toBeTruthy();
        expect(typeof track.thumbnailLarge).toBe("string");
      }
    }
  }, 15000);

  it("should have all 12 genres defined", () => {
    expect(GENRES.length).toBe(12);
    const ids = GENRES.map(g => g.id);
    expect(ids).toContain("alabanza");
    expect(ids).toContain("reggaeton");
    expect(ids).toContain("salsa");
    expect(ids).toContain("bachata");
    expect(ids).toContain("cumbia");
    expect(ids).toContain("pop-latino");
    expect(ids).toContain("ranchera");
    expect(ids).toContain("regional-mexicano");
    expect(ids).toContain("trap-latino");
    expect(ids).toContain("balada");
    expect(ids).toContain("rock-latino");
    expect(ids).toContain("merengue");
  });
});
