/**
 * Invidious API - Alternative to YouTube Data API with no quota limits
 * Uses public Invidious instances to search and fetch video information
 */

export interface InvidiousVideo {
  videoId: string;
  title: string;
  author: string;
  authorId: string;
  thumbnail: string;
  lengthSeconds: number;
  viewCount: number;
  published: number;
  publishedText: string;
}

// Public Invidious instances (fallback list)
const INVIDIOUS_INSTANCES = [
  "https://invidious.io",
  "https://inv.nadeko.net",
  "https://invidious.snopyta.org",
  "https://invidious.kavin.rocks",
];

let currentInstanceIndex = 0;

function getNextInstance(): string {
  const instance = INVIDIOUS_INSTANCES[currentInstanceIndex];
  currentInstanceIndex = (currentInstanceIndex + 1) % INVIDIOUS_INSTANCES.length;
  return instance;
}

async function invidiousFetch(endpoint: string, params: Record<string, string | number>): Promise<any> {
  const maxRetries = INVIDIOUS_INSTANCES.length;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const instance = getNextInstance();
      const url = new URL(`${instance}/api/v1/${endpoint}`);
      
      for (const [key, value] of Object.entries(params)) {
        url.searchParams.set(key, String(value));
      }

      const response = await fetch(url.toString(), {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      });

      if (!response.ok) {
        throw new Error(`Invidious API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      lastError = error as Error;
      console.error(`[Invidious] Attempt ${attempt + 1} failed:`, lastError.message);
      // Try next instance
      continue;
    }
  }

  throw lastError || new Error("All Invidious instances failed");
}

export async function searchInvidiousVideos(
  query: string,
  limit: number = 20
): Promise<InvidiousVideo[]> {
  try {
    console.log(`[Invidious] Searching for: ${query}`);
    
    const data = await invidiousFetch("search", {
      q: `${query} music`,
      type: "video",
      sort_by: "relevance",
      duration: "short",
    });

    if (!Array.isArray(data)) {
      console.log(`[Invidious] Invalid response format`);
      return [];
    }

    const videos: InvidiousVideo[] = [];
    
    for (const item of data) {
      if (item.type !== "video") continue;
      
      // Skip videos longer than 10 minutes (likely not songs)
      if (item.lengthSeconds && item.lengthSeconds > 600) continue;
      
      videos.push({
        videoId: item.videoId,
        title: item.title,
        author: item.author,
        authorId: item.authorId,
        thumbnail: item.videoThumbnails?.[item.videoThumbnails.length - 1]?.url || 
                   `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
        lengthSeconds: item.lengthSeconds || 0,
        viewCount: item.viewCount || 0,
        published: item.published || 0,
        publishedText: item.publishedText || "",
      });

      if (videos.length >= limit) break;
    }

    console.log(`[Invidious] Found ${videos.length} videos`);
    return videos;
  } catch (error) {
    console.error("[Invidious] Search error:", error);
    return [];
  }
}

export async function getTrendingInvidious(limit: number = 20): Promise<InvidiousVideo[]> {
  try {
    console.log(`[Invidious] Fetching trending videos`);
    
    const data = await invidiousFetch("trending", {
      region: "MX",
    });

    if (!Array.isArray(data)) {
      console.log(`[Invidious] Invalid trending response format`);
      return [];
    }

    const videos: InvidiousVideo[] = [];
    
    for (const item of data) {
      if (item.type !== "video") continue;
      
      // Skip videos longer than 10 minutes
      if (item.lengthSeconds && item.lengthSeconds > 600) continue;
      
      videos.push({
        videoId: item.videoId,
        title: item.title,
        author: item.author,
        authorId: item.authorId,
        thumbnail: item.videoThumbnails?.[item.videoThumbnails.length - 1]?.url || 
                   `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
        lengthSeconds: item.lengthSeconds || 0,
        viewCount: item.viewCount || 0,
        published: item.published || 0,
        publishedText: item.publishedText || "",
      });

      if (videos.length >= limit) break;
    }

    console.log(`[Invidious] Found ${videos.length} trending videos`);
    return videos;
  } catch (error) {
    console.error("[Invidious] Trending error:", error);
    return [];
  }
}

export async function getPopularInvidious(query: string, limit: number = 20): Promise<InvidiousVideo[]> {
  return searchInvidiousVideos(query, limit);
}
