import { ENV } from "./_core/env";

const JAMENDO_BASE = "https://api.jamendo.com/v3.0";
const CLIENT_ID = ENV.jamendoClientId;

export interface JamendoTrack {
  id: string;
  name: string;
  duration: number;
  artist_id: string;
  artist_name: string;
  album_id: string;
  album_name: string;
  album_image: string;
  audio: string;
  audiodownload: string;
  image: string;
  shareurl: string;
  releasedate: string;
}

export interface JamendoArtist {
  id: string;
  name: string;
  website: string;
  joindate: string;
  image: string;
  shorturl: string;
  shareurl: string;
}

export interface JamendoAlbum {
  id: string;
  name: string;
  releasedate: string;
  artist_id: string;
  artist_name: string;
  image: string;
  zip: string;
  shorturl: string;
  shareurl: string;
}

async function jamendoFetch<T>(endpoint: string, params: Record<string, string | number>): Promise<T[]> {
  const url = new URL(`${JAMENDO_BASE}/${endpoint}/`);
  url.searchParams.set("client_id", CLIENT_ID);
  url.searchParams.set("format", "json");
  url.searchParams.set("audioformat", "mp32");
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, String(value));
  }

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`Jamendo API error: ${res.status}`);
  const data = await res.json() as { headers: { status: string }; results: T[] };
  if (data.headers.status !== "success") throw new Error("Jamendo API returned non-success status");
  return data.results;
}

// Géneros latinos para búsqueda
const LATIN_TAGS = ["salsa", "reggaeton", "cumbia", "bachata", "merengue", "latin", "tropical", "bossa nova", "tango", "flamenco"];

export async function getLatinTracks(limit = 20, offset = 0): Promise<JamendoTrack[]> {
  const tag = LATIN_TAGS[Math.floor(Math.random() * 5)]; // salsa, reggaeton, cumbia, bachata, merengue
  return jamendoFetch<JamendoTrack>("tracks", {
    limit,
    offset,
    fuzzytags: tag,
    order: "popularity_total",
    include: "musicinfo",
  });
}

export async function getPopularLatinTracks(limit = 30): Promise<JamendoTrack[]> {
  // Buscar en múltiples géneros latinos
  const results: JamendoTrack[] = [];
  const genres = ["salsa", "reggaeton", "cumbia", "bachata", "merengue"];
  for (const genre of genres) {
    try {
      const tracks = await jamendoFetch<JamendoTrack>("tracks", {
        limit: Math.ceil(limit / genres.length),
        fuzzytags: genre,
        order: "popularity_total",
        include: "musicinfo",
      });
      results.push(...tracks);
    } catch {
      // continuar con el siguiente género
    }
  }
  return results.slice(0, limit);
}

export async function searchTracks(query: string, limit = 20): Promise<JamendoTrack[]> {
  return jamendoFetch<JamendoTrack>("tracks", {
    limit,
    namesearch: query,
    order: "popularity_total",
    include: "musicinfo",
  });
}

export async function searchArtists(query: string, limit = 10): Promise<JamendoArtist[]> {
  return jamendoFetch<JamendoArtist>("artists", {
    limit,
    namesearch: query,
    order: "popularity_total",
  });
}

export async function searchAlbums(query: string, limit = 10): Promise<JamendoAlbum[]> {
  return jamendoFetch<JamendoAlbum>("albums", {
    limit,
    namesearch: query,
    order: "popularity_total",
  });
}

export async function getArtistTracks(artistId: string, limit = 20): Promise<JamendoTrack[]> {
  return jamendoFetch<JamendoTrack>("tracks", {
    limit,
    artist_id: artistId,
    order: "popularity_total",
    include: "musicinfo",
  });
}

export async function getArtistById(artistId: string): Promise<JamendoArtist | null> {
  const results = await jamendoFetch<JamendoArtist>("artists", {
    id: artistId,
    limit: 1,
  });
  return results[0] ?? null;
}

export async function getAlbumById(albumId: string): Promise<JamendoAlbum | null> {
  const results = await jamendoFetch<JamendoAlbum>("albums", {
    id: albumId,
    limit: 1,
  });
  return results[0] ?? null;
}

export async function getAlbumTracks(albumId: string): Promise<JamendoTrack[]> {
  return jamendoFetch<JamendoTrack>("tracks", {
    album_id: albumId,
    limit: 50,
    order: "track_position",
    include: "musicinfo",
  });
}

export async function getLatinArtists(limit = 10): Promise<JamendoArtist[]> {
  return jamendoFetch<JamendoArtist>("artists", {
    limit,
    fuzzytags: "latin",
    order: "popularity_total",
  });
}

export async function getLatinAlbums(limit = 10): Promise<JamendoAlbum[]> {
  return jamendoFetch<JamendoAlbum>("albums", {
    limit,
    fuzzytags: "latin salsa cumbia",
    order: "popularity_total",
  });
}

export async function getTrackById(trackId: string): Promise<JamendoTrack | null> {
  const results = await jamendoFetch<JamendoTrack>("tracks", {
    id: trackId,
    limit: 1,
    include: "musicinfo",
  });
  return results[0] ?? null;
}
