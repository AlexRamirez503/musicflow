import { callDataApi } from "./_core/dataApi";
import { searchInvidiousVideos, getTrendingInvidious, getPopularInvidious } from "./invidious";

// Types for YouTube results
export interface YouTubeTrack {
  id: string;
  videoId: string;
  title: string;
  artist: string;
  channelId: string;
  thumbnail: string;
  thumbnailLarge: string;
  duration: string;
  durationSeconds: number;
  views: string;
  publishedAt: string;
  source: "youtube";
}

export interface YouTubeChannel {
  channelId: string;
  title: string;
  thumbnail: string;
  subscribers: string;
  videoCount: string;
  description: string;
}

// Parse duration text like "3:45" or "1:02:30" to seconds
function parseDuration(text: string): number {
  if (!text) return 0;
  const parts = text.split(":").map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] || 0;
}

// Clean up title to extract song name and artist
function cleanTitle(title: string): { songTitle: string; artist: string } {
  // Remove common suffixes
  let cleaned = title
    .replace(/\(Official\s*(Music\s*)?Video\)/gi, "")
    .replace(/\(Official\s*Audio\)/gi, "")
    .replace(/\(Lyric\s*Video\)/gi, "")
    .replace(/\(Lyrics?\)/gi, "")
    .replace(/\(Audio\s*Oficial\)/gi, "")
    .replace(/\(Video\s*Oficial\)/gi, "")
    .replace(/\(Video\s*Lyric\)/gi, "")
    .replace(/\[Official\s*(Music\s*)?Video\]/gi, "")
    .replace(/\[Official\s*Audio\]/gi, "")
    .replace(/\[Audio\s*Oficial\]/gi, "")
    .replace(/\[Video\s*Oficial\]/gi, "")
    .replace(/\(En\s*Vivo\)/gi, "")
    .replace(/\(Live\)/gi, "")
    .replace(/HD|4K|HQ/gi, "")
    .replace(/\s*\|\s*/g, " - ")
    .trim();

  // Try to split artist - title
  const dashMatch = cleaned.match(/^(.+?)\s*[-–—]\s*(.+)$/);
  if (dashMatch) {
    return { artist: dashMatch[1].trim(), songTitle: dashMatch[2].trim() };
  }

  return { songTitle: cleaned, artist: "" };
}

// Search YouTube for music tracks
export async function searchYouTubeTracks(
  query: string,
  language: string = "es",
  country: string = "MX"
): Promise<YouTubeTrack[]> {
  try {
    console.log(`[YouTube] Searching for: ${query}`);
    const result = (await callDataApi("Youtube/search", {
      query: {
        q: `${query} music`,
        hl: language,
        gl: country,
      },
    })) as any;
    console.log(`[YouTube] API Response:`, result ? Object.keys(result) : 'null');
    if (!result || !result.contents) {
      console.log(`[YouTube] No contents in result`);
      return [];
    };

    const tracks: YouTubeTrack[] = [];

    for (const item of result.contents) {
      if (item.type !== "video") continue;
      const video = item.video;
      if (!video || !video.videoId) continue;

      // Skip very long videos (likely not songs)
      const durationSec = video.lengthSeconds || parseDuration(video.lengthText || "");
      if (durationSec > 600) continue; // Skip videos longer than 10 min

      const { songTitle, artist } = cleanTitle(video.title || "");
      const channelTitle = video.channelTitle || "";

      const thumbnails = video.thumbnails || [];
      const smallThumb = thumbnails[0]?.url || "";
      const largeThumb =
        thumbnails[thumbnails.length - 1]?.url ||
        `https://i.ytimg.com/vi/${video.videoId}/hqdefault.jpg`;

      tracks.push({
        id: `yt-${video.videoId}`,
        videoId: video.videoId,
        title: songTitle || video.title || "",
        artist: artist || channelTitle,
        channelId: video.channelId || "",
        thumbnail: smallThumb || `https://i.ytimg.com/vi/${video.videoId}/default.jpg`,
        thumbnailLarge: largeThumb,
        duration: video.lengthText || "",
        durationSeconds: durationSec,
        views: video.viewCountText || "",
        publishedAt: video.publishedTimeText || "",
        source: "youtube",
      });
    }

    return tracks;
  } catch (error) {
    console.error("[YouTube] Search error:", error);
    console.log("[YouTube] Fallback: Using Jamendo instead");
    // Fallback to Jamendo if YouTube fails
    try {
      const { searchTracks } = await import("./jamendo");
      const jamendoTracks = await searchTracks(query, 20);
      // Convert Jamendo tracks to YouTube format
      return jamendoTracks.map(t => ({
        id: `jamendo-${t.id}`,
        videoId: `jamendo-${t.id}`,
        title: t.name,
        artist: t.artist_name,
        channelId: t.artist_id,
        thumbnail: t.album_image || t.image || "",
        thumbnailLarge: t.album_image || t.image || "",
        duration: `${Math.floor(t.duration / 60)}:${String(t.duration % 60).padStart(2, "0")}`,
        durationSeconds: t.duration,
        views: "",
        publishedAt: t.releasedate || "",
        source: "youtube" as const,
      }));
    } catch (jamendoError) {
      console.error("[YouTube] Jamendo fallback error:", jamendoError);
      return [];
    }
  }
}

// Search for curated content by genre/category
export async function getYouTubeByGenre(
  genre: string,
  language: string = "es",
  country: string = "MX"
): Promise<YouTubeTrack[]> {
  const genreQueries: Record<string, string> = {
    "alabanza": "alabanza cristiana worship español",
    "reggaeton": "reggaeton 2024 2025 éxitos",
    "salsa": "salsa romántica éxitos",
    "bachata": "bachata éxitos romántica",
    "cumbia": "cumbia éxitos populares",
    "pop-latino": "pop latino éxitos 2024 2025",
    "ranchera": "ranchera mexicana éxitos",
    "regional-mexicano": "regional mexicano corridos éxitos",
    "trap-latino": "trap latino éxitos",
    "balada": "baladas románticas en español",
    "rock-latino": "rock en español éxitos",
    "merengue": "merengue éxitos bailable",
  };

  const searchQuery = genreQueries[genre] || `${genre} música latina éxitos`;
  return searchYouTubeTracks(searchQuery, language, country);
}

// Get tracks from a specific artist
export async function getArtistTracks(
  artistName: string,
  language: string = "es",
  country: string = "MX"
): Promise<YouTubeTrack[]> {
  return searchYouTubeTracks(`${artistName} canciones`, language, country);
}

// Get popular Latin music
export async function getPopularLatinMusic(): Promise<YouTubeTrack[]> {
  try {
    console.log("[YouTube] Fetching popular Latin music");
    const popularVideos = await getPopularInvidious("música latina éxitos 2024 2025 popular", 20);
    if (popularVideos.length > 0) {
      console.log(`[YouTube] Using Invidious popular: ${popularVideos.length} videos`);
      return popularVideos.map(v => ({
        id: `yt-${v.videoId}`,
        videoId: v.videoId,
        title: v.title,
        artist: v.author,
        channelId: v.authorId,
        thumbnail: v.thumbnail,
        thumbnailLarge: v.thumbnail,
        duration: `${Math.floor(v.lengthSeconds / 60)}:${String(v.lengthSeconds % 60).padStart(2, "0")}`,
        durationSeconds: v.lengthSeconds,
        views: v.viewCount.toString(),
        publishedAt: v.publishedText,
        source: "youtube",
      }));
    }
    return searchYouTubeTracks("música latina éxitos 2024 2025 popular", "es", "MX");
  } catch (error) {
    console.error("[YouTube] Popular Latin error:", error);
    return searchYouTubeTracks("música latina éxitos 2024 2025 popular", "es", "MX");
  }
}

// Get popular Christian/Worship music
export async function getWorshipMusic(): Promise<YouTubeTrack[]> {
  try {
    console.log("[YouTube] Fetching worship music");
    const worshipVideos = await getPopularInvidious("alabanza cristiana adoración Jesús Adrián Romero Marcos Witt", 20);
    if (worshipVideos.length > 0) {
      console.log(`[YouTube] Using Invidious worship: ${worshipVideos.length} videos`);
      return worshipVideos.map(v => ({
        id: `yt-${v.videoId}`,
        videoId: v.videoId,
        title: v.title,
        artist: v.author,
        channelId: v.authorId,
        thumbnail: v.thumbnail,
        thumbnailLarge: v.thumbnail,
        duration: `${Math.floor(v.lengthSeconds / 60)}:${String(v.lengthSeconds % 60).padStart(2, "0")}`,
        durationSeconds: v.lengthSeconds,
        views: v.viewCount.toString(),
        publishedAt: v.publishedText,
        source: "youtube",
      }));
    }
    return searchYouTubeTracks(
      "alabanza cristiana adoración Jesús Adrián Romero Marcos Witt",
      "es",
      "MX"
    );
  } catch (error) {
    console.error("[YouTube] Worship error:", error);
    return searchYouTubeTracks(
      "alabanza cristiana adoración Jesús Adrián Romero Marcos Witt",
      "es",
      "MX"
    );
  }
}

// Get trending music
export async function getTrendingMusic(): Promise<YouTubeTrack[]> {
  try {
    console.log("[YouTube] Fetching trending music");
    const trendingVideos = await getTrendingInvidious(20);
    if (trendingVideos.length > 0) {
      console.log(`[YouTube] Using Invidious trending: ${trendingVideos.length} videos`);
      return trendingVideos.map(v => ({
        id: `yt-${v.videoId}`,
        videoId: v.videoId,
        title: v.title,
        artist: v.author,
        channelId: v.authorId,
        thumbnail: v.thumbnail,
        thumbnailLarge: v.thumbnail,
        duration: `${Math.floor(v.lengthSeconds / 60)}:${String(v.lengthSeconds % 60).padStart(2, "0")}`,
        durationSeconds: v.lengthSeconds,
        views: v.viewCount.toString(),
        publishedAt: v.publishedText,
        source: "youtube",
      }));
    }
    return searchYouTubeTracks("música tendencia latino 2025", "es", "MX");
  } catch (error) {
    console.error("[YouTube] Trending error:", error);
    return searchYouTubeTracks("música tendencia latino 2025", "es", "MX");
  }
}

// Featured artist lists for the home page
export const FEATURED_ARTISTS = {
  alabanza: [
    "Jesús Adrián Romero",
    "Marcos Witt",
    "Christine D'Clario",
    "Marcela Gándara",
    "Alex Campos",
    "Evan Craft",
    "Miel San Marcos",
    "Hillsong en Español",
  ],
  reggaeton: [
    "Bad Bunny",
    "Daddy Yankee",
    "Ozuna",
    "J Balvin",
    "Rauw Alejandro",
    "Farruko",
    "Anuel AA",
    "Karol G",
  ],
  mexico: [
    "Christian Nodal",
    "Peso Pluma",
    "Grupo Firme",
    "Luis Miguel",
    "Marco Antonio Solís",
    "Juan Gabriel",
    "Alejandro Fernández",
    "Natalia Lafourcade",
  ],
  puertoRico: [
    "Bad Bunny",
    "Daddy Yankee",
    "Ozuna",
    "Rauw Alejandro",
    "Don Omar",
    "Wisin y Yandel",
    "Tego Calderón",
    "Ivy Queen",
  ],
  popLatino: [
    "Shakira",
    "Maluma",
    "Sebastián Yatra",
    "Camilo",
    "Ricardo Arjona",
    "Juanes",
    "Enrique Iglesias",
    "Ricky Martin",
  ],
};

export const GENRES = [
  { id: "alabanza", name: "Alabanza y Adoración", color: "#8B5CF6", icon: "🙏" },
  { id: "reggaeton", name: "Reggaeton", color: "#EF4444", icon: "🔥" },
  { id: "salsa", name: "Salsa", color: "#F59E0B", icon: "💃" },
  { id: "bachata", name: "Bachata", color: "#EC4899", icon: "❤️" },
  { id: "cumbia", name: "Cumbia", color: "#10B981", icon: "🎉" },
  { id: "pop-latino", name: "Pop Latino", color: "#3B82F6", icon: "🎵" },
  { id: "ranchera", name: "Ranchera", color: "#D97706", icon: "🤠" },
  { id: "regional-mexicano", name: "Regional Mexicano", color: "#059669", icon: "🇲🇽" },
  { id: "trap-latino", name: "Trap Latino", color: "#7C3AED", icon: "🎤" },
  { id: "balada", name: "Baladas", color: "#DB2777", icon: "💜" },
  { id: "rock-latino", name: "Rock en Español", color: "#DC2626", icon: "🎸" },
  { id: "merengue", name: "Merengue", color: "#F97316", icon: "🥁" },
];
