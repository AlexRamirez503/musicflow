import { describe, expect, it } from "vitest";

const JAMENDO_BASE = "https://api.jamendo.com/v3.0";
const CLIENT_ID = process.env.JAMENDO_CLIENT_ID || "4bef6fe7";

describe("Jamendo API integration", () => {
  it("should fetch latin tracks with valid audio URLs", async () => {
    const url = `${JAMENDO_BASE}/tracks/?client_id=${CLIENT_ID}&format=json&limit=5&fuzzytags=salsa&order=popularity_total&audioformat=mp32`;
    const res = await fetch(url);
    expect(res.ok).toBe(true);

    const data = await res.json();
    expect(data.headers.status).toBe("success");
    expect(data.results.length).toBeGreaterThan(0);

    const track = data.results[0];
    expect(track.name).toBeTruthy();
    expect(track.artist_name).toBeTruthy();
    expect(track.audio).toMatch(/^https?:\/\//);
  });

  it("should search tracks by name", async () => {
    const url = `${JAMENDO_BASE}/tracks/?client_id=${CLIENT_ID}&format=json&limit=5&namesearch=salsa&order=popularity_total&audioformat=mp32`;
    const res = await fetch(url);
    expect(res.ok).toBe(true);

    const data = await res.json();
    expect(data.headers.status).toBe("success");
  });

  it("should fetch artists", async () => {
    const url = `${JAMENDO_BASE}/artists/?client_id=${CLIENT_ID}&format=json&limit=5&fuzzytags=latin&order=popularity_total`;
    const res = await fetch(url);
    expect(res.ok).toBe(true);

    const data = await res.json();
    expect(data.headers.status).toBe("success");
    expect(data.results.length).toBeGreaterThan(0);

    const artist = data.results[0];
    expect(artist.name).toBeTruthy();
    expect(artist.id).toBeTruthy();
  });

  it("should fetch albums", async () => {
    const url = `${JAMENDO_BASE}/albums/?client_id=${CLIENT_ID}&format=json&limit=5&order=popularity_total`;
    const res = await fetch(url);
    expect(res.ok).toBe(true);

    const data = await res.json();
    expect(data.headers.status).toBe("success");
    expect(data.results.length).toBeGreaterThan(0);
  });

  it("should return audio URLs that are accessible", async () => {
    const url = `${JAMENDO_BASE}/tracks/?client_id=${CLIENT_ID}&format=json&limit=1&fuzzytags=latin&order=popularity_total&audioformat=mp32`;
    const res = await fetch(url);
    const data = await res.json();
    const audioUrl = data.results[0]?.audio;

    expect(audioUrl).toBeTruthy();

    // Verify audio URL is reachable (HEAD request)
    const audioRes = await fetch(audioUrl, { method: "HEAD" });
    expect(audioRes.ok).toBe(true);
  });
});
