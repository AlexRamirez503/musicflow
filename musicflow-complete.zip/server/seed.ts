import { getDb } from "./db";
import { artists, albums, songs } from "../drizzle/schema";

export async function runSeed() {
  const db = await getDb();
  if (!db) return { success: false, message: "DB no disponible" };

  // Check if already seeded
  const existing = await db.select().from(artists).limit(1);
  if (existing.length > 0) return { success: true, message: "Ya tiene datos" };

  // Insert artists
  await db.insert(artists).values([
    { name: "Luna Valeria", bio: "Cantautora de pop latino con influencias acústicas.", genre: "Pop Latino", imageUrl: "https://picsum.photos/seed/artist1/400/400" },
    { name: "El Combo Urbano", bio: "Grupo de reggaeton y trap urbano.", genre: "Reggaeton", imageUrl: "https://picsum.photos/seed/artist2/400/400" },
    { name: "Marcos Fierro", bio: "Guitarrista y compositor de rock alternativo.", genre: "Rock", imageUrl: "https://picsum.photos/seed/artist3/400/400" },
    { name: "Nadia Sol", bio: "Artista de electrónica y pop experimental.", genre: "Electrónica", imageUrl: "https://picsum.photos/seed/artist4/400/400" },
    { name: "Trio Raíces", bio: "Fusión de cumbia y folklore latinoamericano.", genre: "Cumbia", imageUrl: "https://picsum.photos/seed/artist5/400/400" },
    { name: "Sebastián Vega", bio: "Cantautor de baladas y pop acústico.", genre: "Pop Acústico", imageUrl: "https://picsum.photos/seed/artist6/400/400" },
  ]);

  const insertedArtists = await db.select().from(artists);
  const artistMap: Record<string, number> = {};
  for (const a of insertedArtists) artistMap[a.name] = a.id;

  // Insert albums
  await db.insert(albums).values([
    { title: "Amanecer", artistId: artistMap["Luna Valeria"], coverUrl: "https://picsum.photos/seed/album1/300/300", releaseYear: 2023, genre: "Pop Latino" },
    { title: "Noches de Neon", artistId: artistMap["El Combo Urbano"], coverUrl: "https://picsum.photos/seed/album2/300/300", releaseYear: 2024, genre: "Reggaeton" },
    { title: "Tormenta Eléctrica", artistId: artistMap["Marcos Fierro"], coverUrl: "https://picsum.photos/seed/album3/300/300", releaseYear: 2022, genre: "Rock" },
    { title: "Frecuencias", artistId: artistMap["Nadia Sol"], coverUrl: "https://picsum.photos/seed/album4/300/300", releaseYear: 2024, genre: "Electrónica" },
    { title: "Raíces Vivas", artistId: artistMap["Trio Raíces"], coverUrl: "https://picsum.photos/seed/album5/300/300", releaseYear: 2023, genre: "Cumbia" },
    { title: "Momentos", artistId: artistMap["Sebastián Vega"], coverUrl: "https://picsum.photos/seed/album6/300/300", releaseYear: 2023, genre: "Pop Acústico" },
  ]);

  const insertedAlbums = await db.select().from(albums);
  const albumMap: Record<string, number> = {};
  for (const al of insertedAlbums) albumMap[al.title] = al.id;

  // Demo audio URL (short public domain sample)
  const demoAudio = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";
  const demoAudio2 = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3";
  const demoAudio3 = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3";

  // Insert songs
  await db.insert(songs).values([
    // Luna Valeria - Amanecer
    { title: "Primer Rayo", artistId: artistMap["Luna Valeria"], albumId: albumMap["Amanecer"], audioUrl: demoAudio, coverUrl: "https://picsum.photos/seed/song1/300/300", duration: 210, trackNumber: 1, genre: "Pop Latino", plays: 1200 },
    { title: "Cielo Abierto", artistId: artistMap["Luna Valeria"], albumId: albumMap["Amanecer"], audioUrl: demoAudio2, coverUrl: "https://picsum.photos/seed/song2/300/300", duration: 195, trackNumber: 2, genre: "Pop Latino", plays: 980 },
    { title: "Volver a Empezar", artistId: artistMap["Luna Valeria"], albumId: albumMap["Amanecer"], audioUrl: demoAudio3, coverUrl: "https://picsum.photos/seed/song3/300/300", duration: 230, trackNumber: 3, genre: "Pop Latino", plays: 870 },
    // El Combo Urbano - Noches de Neon
    { title: "La Calle Llama", artistId: artistMap["El Combo Urbano"], albumId: albumMap["Noches de Neon"], audioUrl: demoAudio, coverUrl: "https://picsum.photos/seed/song4/300/300", duration: 185, trackNumber: 1, genre: "Reggaeton", plays: 2100 },
    { title: "Fuego y Ritmo", artistId: artistMap["El Combo Urbano"], albumId: albumMap["Noches de Neon"], audioUrl: demoAudio2, coverUrl: "https://picsum.photos/seed/song5/300/300", duration: 200, trackNumber: 2, genre: "Reggaeton", plays: 1750 },
    { title: "Sin Parar", artistId: artistMap["El Combo Urbano"], albumId: albumMap["Noches de Neon"], audioUrl: demoAudio3, coverUrl: "https://picsum.photos/seed/song6/300/300", duration: 178, trackNumber: 3, genre: "Reggaeton", plays: 1600 },
    // Marcos Fierro - Tormenta Eléctrica
    { title: "Distorsión", artistId: artistMap["Marcos Fierro"], albumId: albumMap["Tormenta Eléctrica"], audioUrl: demoAudio, coverUrl: "https://picsum.photos/seed/song7/300/300", duration: 245, trackNumber: 1, genre: "Rock", plays: 950 },
    { title: "Corriente Alterna", artistId: artistMap["Marcos Fierro"], albumId: albumMap["Tormenta Eléctrica"], audioUrl: demoAudio2, coverUrl: "https://picsum.photos/seed/song8/300/300", duration: 260, trackNumber: 2, genre: "Rock", plays: 820 },
    // Nadia Sol - Frecuencias
    { title: "Pulso Digital", artistId: artistMap["Nadia Sol"], albumId: albumMap["Frecuencias"], audioUrl: demoAudio3, coverUrl: "https://picsum.photos/seed/song9/300/300", duration: 220, trackNumber: 1, genre: "Electrónica", plays: 1100 },
    { title: "Onda Expansiva", artistId: artistMap["Nadia Sol"], albumId: albumMap["Frecuencias"], audioUrl: demoAudio, coverUrl: "https://picsum.photos/seed/song10/300/300", duration: 235, trackNumber: 2, genre: "Electrónica", plays: 990 },
    // Trio Raíces - Raíces Vivas
    { title: "Tierra y Sal", artistId: artistMap["Trio Raíces"], albumId: albumMap["Raíces Vivas"], audioUrl: demoAudio2, coverUrl: "https://picsum.photos/seed/song11/300/300", duration: 190, trackNumber: 1, genre: "Cumbia", plays: 760 },
    { title: "Camino al Sur", artistId: artistMap["Trio Raíces"], albumId: albumMap["Raíces Vivas"], audioUrl: demoAudio3, coverUrl: "https://picsum.photos/seed/song12/300/300", duration: 205, trackNumber: 2, genre: "Cumbia", plays: 680 },
    // Sebastián Vega - Momentos
    { title: "Entre Palabras", artistId: artistMap["Sebastián Vega"], albumId: albumMap["Momentos"], audioUrl: demoAudio, coverUrl: "https://picsum.photos/seed/song13/300/300", duration: 215, trackNumber: 1, genre: "Pop Acústico", plays: 1050 },
    { title: "Tarde de Lluvia", artistId: artistMap["Sebastián Vega"], albumId: albumMap["Momentos"], audioUrl: demoAudio2, coverUrl: "https://picsum.photos/seed/song14/300/300", duration: 200, trackNumber: 2, genre: "Pop Acústico", plays: 890 },
  ]);

  return { success: true, message: "Datos de muestra cargados correctamente" };
}
