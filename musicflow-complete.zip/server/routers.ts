import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getAllArtists, getArtistById, getArtistAlbums, getArtistSongs, createArtist,
  getAllAlbums, getAlbumById, getAlbumSongs, createAlbum,
  getAllSongs, getSongById, getRecentSongs, incrementSongPlays, createSong,
  searchAll,
  getUserPlaylists, getPlaylistById, getPlaylistSongs,
  createPlaylist, updatePlaylist, deletePlaylist,
  addSongToPlaylist, removeSongFromPlaylist,
  getUserLibrary, toggleLibraryItem, isInLibrary,
  seedDatabase,
} from "./db";
import { storagePut } from "./storage";
import {
  getPopularLatinTracks, getLatinTracks, searchTracks, searchArtists, searchAlbums,
  getArtistTracks, getArtistById as getJamendoArtist, getAlbumById as getJamendoAlbum,
  getAlbumTracks, getLatinArtists, getLatinAlbums, getTrackById,
} from "./jamendo";
import {
  searchYouTubeTracks, getYouTubeByGenre, getPopularLatinMusic,
  getWorshipMusic, getTrendingMusic, getArtistTracks as getYTArtistTracks,
  FEATURED_ARTISTS, GENRES,
} from "./youtube";

// ── Artists ────────────────────────────────────────────────────────────────
const artistsRouter = router({
  list: publicProcedure.query(() => getAllArtists()),
  byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getArtistById(input.id)),
  albums: publicProcedure.input(z.object({ artistId: z.number() })).query(({ input }) => getArtistAlbums(input.artistId)),
  songs: publicProcedure.input(z.object({ artistId: z.number() })).query(({ input }) => getArtistSongs(input.artistId)),
  create: protectedProcedure
    .input(z.object({ name: z.string().min(1), bio: z.string().optional(), imageUrl: z.string().optional(), genre: z.string().optional() }))
    .mutation(({ input }) => createArtist(input)),
});

// ── Albums ─────────────────────────────────────────────────────────────────
const albumsRouter = router({
  list: publicProcedure.query(() => getAllAlbums()),
  byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getAlbumById(input.id)),
  songs: publicProcedure.input(z.object({ albumId: z.number() })).query(({ input }) => getAlbumSongs(input.albumId)),
  create: protectedProcedure
    .input(z.object({ title: z.string().min(1), artistId: z.number(), coverUrl: z.string().optional(), releaseYear: z.number().optional(), genre: z.string().optional() }))
    .mutation(({ input }) => createAlbum(input)),
});

// ── Songs ──────────────────────────────────────────────────────────────────
const songsRouter = router({
  list: publicProcedure.query(() => getAllSongs()),
  recent: publicProcedure.query(() => getRecentSongs()),
  byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getSongById(input.id)),
  play: publicProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => incrementSongPlays(input.id)),
  create: protectedProcedure
    .input(z.object({
      title: z.string().min(1), artistId: z.number(), albumId: z.number().optional(),
      audioUrl: z.string().min(1), coverUrl: z.string().optional(),
      duration: z.number().optional(), trackNumber: z.number().optional(), genre: z.string().optional(),
    }))
    .mutation(({ input }) => createSong(input)),
});

// ── Search ─────────────────────────────────────────────────────────────────
const searchRouter = router({
  query: publicProcedure.input(z.object({ q: z.string().min(1) })).query(({ input }) => searchAll(input.q)),
});

// ── Playlists ──────────────────────────────────────────────────────────────
const playlistsRouter = router({
  myPlaylists: protectedProcedure.query(({ ctx }) => getUserPlaylists(ctx.user.id)),
  byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) => getPlaylistById(input.id)),
  songs: publicProcedure.input(z.object({ playlistId: z.number() })).query(({ input }) => getPlaylistSongs(input.playlistId)),
  create: protectedProcedure
    .input(z.object({ name: z.string().min(1), description: z.string().optional(), coverUrl: z.string().optional() }))
    .mutation(({ ctx, input }) => createPlaylist({ ...input, userId: ctx.user.id })),
  update: protectedProcedure
    .input(z.object({ id: z.number(), name: z.string().optional(), description: z.string().optional(), coverUrl: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const playlist = await getPlaylistById(input.id);
      if (!playlist || playlist.userId !== ctx.user.id) throw new Error("Not authorized");
      const { id, ...data } = input;
      return updatePlaylist(id, data);
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const playlist = await getPlaylistById(input.id);
      if (!playlist || playlist.userId !== ctx.user.id) throw new Error("Not authorized");
      return deletePlaylist(input.id);
    }),
  addSong: protectedProcedure
    .input(z.object({ playlistId: z.number(), songId: z.number() }))
    .mutation(({ input }) => addSongToPlaylist(input.playlistId, input.songId)),
  removeSong: protectedProcedure
    .input(z.object({ playlistId: z.number(), songId: z.number() }))
    .mutation(({ input }) => removeSongFromPlaylist(input.playlistId, input.songId)),
});

// ── Library ────────────────────────────────────────────────────────────────
const libraryRouter = router({
  get: protectedProcedure.query(({ ctx }) => getUserLibrary(ctx.user.id)),
  toggle: protectedProcedure
    .input(z.object({ type: z.enum(["song", "album", "artist"]), itemId: z.number() }))
    .mutation(({ ctx, input }) => toggleLibraryItem(ctx.user.id, input.type, input.itemId)),
  check: protectedProcedure
    .input(z.object({ type: z.enum(["song", "album", "artist"]), itemId: z.number() }))
    .query(({ ctx, input }) => isInLibrary(ctx.user.id, input.type, input.itemId)),
});

// ── Upload ─────────────────────────────────────────────────────────────────
const uploadRouter = router({
  audio: protectedProcedure
    .input(z.object({ fileName: z.string(), fileBase64: z.string(), mimeType: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const allowed = ["audio/mpeg", "audio/wav", "audio/mp3"];
      if (!allowed.includes(input.mimeType)) throw new Error("Solo se permiten archivos MP3 y WAV");
      const buffer = Buffer.from(input.fileBase64, "base64");
      const key = `audio/${ctx.user.id}/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      return { url, key };
    }),
  image: protectedProcedure
    .input(z.object({ fileName: z.string(), fileBase64: z.string(), mimeType: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const allowed = ["image/jpeg", "image/png", "image/webp"];
      if (!allowed.includes(input.mimeType)) throw new Error("Solo se permiten imágenes JPG, PNG y WebP");
      const buffer = Buffer.from(input.fileBase64, "base64");
      const key = `images/${ctx.user.id}/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      return { url, key };
    }),
});

// ── Jamendo ───────────────────────────────────────────────────────────────
const jamendoRouter = router({
  latinTracks: publicProcedure
    .input(z.object({ limit: z.number().optional(), offset: z.number().optional() }))
    .query(({ input }) => getLatinTracks(input.limit ?? 20, input.offset ?? 0)),

  popularLatin: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => getPopularLatinTracks(input.limit ?? 30)),

  search: publicProcedure
    .input(z.object({ q: z.string().min(1), limit: z.number().optional() }))
    .query(({ input }) => Promise.all([
      searchTracks(input.q, input.limit ?? 20),
      searchArtists(input.q, 5),
      searchAlbums(input.q, 5),
    ]).then(([tracks, artists, albums]) => ({ tracks, artists, albums }))),

  artistTracks: publicProcedure
    .input(z.object({ artistId: z.string(), limit: z.number().optional() }))
    .query(({ input }) => getArtistTracks(input.artistId, input.limit ?? 20)),

  artist: publicProcedure
    .input(z.object({ artistId: z.string() }))
    .query(({ input }) => getJamendoArtist(input.artistId)),

  album: publicProcedure
    .input(z.object({ albumId: z.string() }))
    .query(({ input }) => getJamendoAlbum(input.albumId)),

  albumTracks: publicProcedure
    .input(z.object({ albumId: z.string() }))
    .query(({ input }) => getAlbumTracks(input.albumId)),

  latinArtists: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => getLatinArtists(input.limit ?? 10)),

  latinAlbums: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => getLatinAlbums(input.limit ?? 10)),

  track: publicProcedure
    .input(z.object({ trackId: z.string() }))
    .query(({ input }) => getTrackById(input.trackId)),
});

// ── YouTube ──────────────────────────────────────────────────────────────
const youtubeRouter = router({
  search: publicProcedure
    .input(z.object({ q: z.string().min(1) }))
    .query(({ input }) => searchYouTubeTracks(input.q)),

  genre: publicProcedure
    .input(z.object({ genre: z.string() }))
    .query(({ input }) => getYouTubeByGenre(input.genre)),

  popularLatin: publicProcedure
    .query(() => getPopularLatinMusic()),

  worship: publicProcedure
    .query(() => getWorshipMusic()),

  trending: publicProcedure
    .query(() => getTrendingMusic()),

  artistTracks: publicProcedure
    .input(z.object({ artistName: z.string() }))
    .query(({ input }) => getYTArtistTracks(input.artistName)),

  featuredArtists: publicProcedure
    .query(() => FEATURED_ARTISTS),

  genres: publicProcedure
    .query(() => GENRES),
});

// ── Seed ───────────────────────────────────────────────────────────────────
const seedRouter = router({
  run: publicProcedure.mutation(() => seedDatabase()),
});

// ── App Router ─────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  artists: artistsRouter,
  albums: albumsRouter,
  songs: songsRouter,
  search: searchRouter,
  playlists: playlistsRouter,
  library: libraryRouter,
  upload: uploadRouter,
  seed: seedRouter,
  jamendo: jamendoRouter,
  youtube: youtubeRouter,
});

export type AppRouter = typeof appRouter;
