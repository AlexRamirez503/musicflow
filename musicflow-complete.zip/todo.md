# MusicFlow - TODO

## Base de datos y backend
- [x] Schema: tablas artists, albums, songs, playlists, playlist_songs, user_library
- [x] Migración y aplicación de SQL
- [x] Seed de datos de muestra (artistas, álbumes, canciones)
- [x] DB helpers: canciones, artistas, álbumes, playlists, biblioteca
- [x] Router tRPC: songs, artists, albums, playlists, library, upload, search

## Frontend - Layout y navegación
- [x] Tema oscuro global (Spotify-like) en index.css
- [x] Layout principal con sidebar izquierdo fijo
- [x] Reproductor inferior fijo con controles completos
- [x] Contexto global de audio (PlayerContext)
- [x] Rutas: /, /search, /library, /artist/:id, /album/:id, /playlist/:id, /upload
- [x] Navbar móvil inferior para Android

## Pantallas
- [x] Home: secciones de recientes, artistas populares, playlists recomendadas
- [x] Search: búsqueda en tiempo real de canciones/artistas/álbumes
- [x] Library: canciones guardadas, álbumes y playlists favoritas
- [x] Artist detail: foto, bio, discografía y canciones populares
- [x] Album detail: portada, tracklist y botón de reproducción
- [x] Playlist detail: portada, canciones y gestión

## Reproductor
- [x] Play / Pausa
- [x] Siguiente / Anterior
- [x] Barra de progreso con seek
- [x] Control de volumen con mute
- [x] Shuffle y repeat
- [x] Mini portada + título + artista en reproductor

## Playlists
- [x] Crear playlist
- [x] Editar nombre
- [x] Eliminar playlist
- [x] Agregar canción a playlist
- [x] Quitar canción de playlist

## Subida de archivos
- [x] Subir archivo de audio (MP3/WAV) a S3
- [x] Subir portada de álbum/playlist a S3
- [x] Streaming de audio desde S3

## Autenticación
- [x] Login con Manus OAuth
- [x] Guardar biblioteca personal por usuario
- [x] Proteger rutas de biblioteca y playlists

## PWA / Android
- [x] manifest.json para instalación en Android
- [x] Meta tags PWA (theme-color, mobile-web-app-capable)
- [x] Navbar móvil inferior para pantallas pequeñas
- [x] Diseño responsivo para móvil

## Tests y entrega
- [x] Tests vitest para routers principales (14 tests pasando)
- [x] Checkpoint final

## Rediseño visual estilo Spotify
- [x] CSS global: colores exactos de Spotify (#121212, #1db954, #282828, #b3b3b3)
- [x] Tipografía Circular/Inter con pesos correctos
- [x] Sidebar rediseñado con fondo #000, secciones y hover states de Spotify
- [x] Reproductor inferior rediseñado con 3 columnas (info / controles / volumen)
- [x] Navegación móvil inferior estilo Spotify
- [x] Home: gradientes de color, secciones con scroll horizontal en móvil
- [x] Cards de canciones/álbumes con sombra y hover play button
- [x] Pantalla de artista con hero gradient y overlay
- [x] Pantalla de álbum con header gradient
- [x] Pantalla de búsqueda con grid de géneros coloridos
- [x] SongRow con numeración, hover state y duración alineada

## Integración Jamendo API (música latina real)
- [x] Configurar Client ID de Jamendo como variable de entorno
- [x] Servicio backend jamendo.ts con endpoints de tracks, artistas y búsqueda
- [x] Router tRPC jamendo: tracks latinos, búsqueda, artistas, álbumes
- [x] Home: cargar tracks latinos reales desde Jamendo
- [x] Búsqueda: resultados reales de Jamendo
- [x] Reproductor: streaming de audio real desde URLs de Jamendo
- [x] Pantalla de artista con datos reales de Jamendo

## Conectar toda la música Jamendo en la UI
- [x] Home: secciones con tracks latinos populares, artistas y álbumes reales
- [x] Búsqueda: resultados de Jamendo en tiempo real
- [x] Pantalla de artista Jamendo con canciones reales
- [x] Pantalla de álbum Jamendo con tracklist real
- [x] Reproductor: streaming de audio real desde Jamendo
- [x] Test de validación de Jamendo API (5 tests pasando)

## Generación de APK Android
- [x] Instalar Bubblewrap, JDK y Android SDK
- [x] Configurar proyecto TWA con URL pública
- [x] Generar APK firmado
- [x] Entregar APK al usuario

## Bug Fix APK
- [x] Corregir LauncherActivity que se queda en splash - usar WebView como fallback principal
- [x] Recompilar y entregar APK corregido

## Integración YouTube (música completa de artistas conocidos)
- [x] Obtener YouTube Data API key (usando Manus Data API integrada)
- [x] Crear servicio backend youtube.ts con búsqueda de videos musicales
- [x] Crear router tRPC youtube con endpoints de búsqueda y artistas
- [x] Integrar YouTube IFrame Player API oculto en PlayerContext
- [x] Actualizar componente Player para soportar reproducción YouTube oculta
- [x] Actualizar Home con secciones de artistas latinos conocidos y alabanza
- [x] Actualizar Search para buscar en YouTube
- [x] Mantener Jamendo como fuente secundaria de música indie
- [x] Recompilar APK con cambios (v2.0.0)

## Bug Fix: Video visible y música se detiene con pantalla apagada
- [x] Ocultar completamente el iframe de YouTube (no debe verse el video)
- [x] Implementar Media Session API para reproducción en segundo plano
- [x] Actualizar APK con soporte de reproducción en background (WakeLock + no pause WebView)
- [x] Recompilar y entregar APK corregido (v2.1.0)

## Bug Fix: Música se detiene al navegar entre pantallas
- [x] Mover iframe YouTube a posición fija off-screen con 1x1 para mantenerlo vivo
- [x] Corregir navegación: MobileNav usa Link de wouter, Sidebar usa navigate(), Playlist usa navigate()

## Bug Fix: Música se detiene al apagar pantalla (v2)
- [x] Implementar Foreground Service nativo (AudioService.java) con WakeLock y notificación persistente
- [x] Notificación persistente con botón Detener + JavaScript Bridge para comunicación web-nativo
- [x] Recompilar APK v3.0.0 con Foreground Service

## Perfil de artista completo
- [x] Pantalla de perfil de artista con foto grande tipo hero/banner
- [x] Listado de todas las canciones del artista desde YouTube
- [x] Conectar chips de artistas en Home a la pantalla de perfil
- [x] Conectar resultados de búsqueda de artistas a la pantalla de perfil
- [x] Botón "Reproducir todo" para iniciar todas las canciones del artista
- [x] Agregar foto/avatar circular del artista en YouTubeArtist.tsx
- [x] Hacer nombre del artista clickeable en SongRow para navegar al perfil
- [x] Agregar artistas de YouTube como tarjetas en resultados de búsqueda

## APK Autónomo (sin servidor backend)
- [ ] Crear proyecto HTML/CSS/JS estático autónomo
- [ ] Implementar servicio YouTube (búsqueda, trending, artistas) via Invidious API
- [ ] Implementar servicio Jamendo directo desde frontend
- [ ] UI Home con chips de artistas, géneros, tendencias
- [ ] UI Búsqueda con resultados de YouTube y Jamendo
- [ ] UI Perfil de artista con foto y todas las canciones
- [ ] UI Géneros con canciones por género
- [ ] Reproductor con YouTube IFrame oculto y Jamendo audio
- [ ] Integrar en Android WebView con Foreground Service
- [ ] Compilar y firmar APK autónomo

## Rediseño Home estilo Spotify (APK autónomo)
- [x] Grid 2 columnas con tarjetas rectangulares de artistas (foto+nombre) estilo Spotify
- [x] Filtros arriba (Todas, Música) estilo Spotify
- [x] Secciones de tendencias y géneros debajo del grid
- [x] Compilar y entregar APK con nuevo diseño

## Bug Fix: Música YouTube se detiene al apagar pantalla (APK autónomo)
- [ ] Prevenir que WebView se pause al apagar pantalla (onPause override)
- [ ] Mejorar Foreground Service con WakeLock para mantener CPU activa
- [x] Compilar y entregar APK corregido

## Notificación de medios estilo Spotify en pantalla de bloqueo
- [x] AudioService con MediaSession nativa y MediaStyle notification
- [x] Controles play/pausa/next/prev en notificación y pantalla de bloqueo
- [x] Portada del álbum en la notificación
- [x] MediaWebView para mantener audio con pantalla apagada
- [x] Bridge JS para enviar portada al servicio nativo
- [x] Compilar y entregar APK

## Persistencia de última canción
- [x] Guardar última canción y cola en localStorage al reproducir
- [x] Restaurar última canción en el player bar al abrir la app
- [ ] Compilar y entregar APK

## Grid de artistas más escuchados en Home
- [x] Tracking de reproducciones por artista en localStorage
- [x] Grid dinámico con los artistas más escuchados y su foto de perfil
- [x] Fallback a mensaje vacío si no hay historial
- [ ] Compilar y entregar APK

## Quitar géneros del Home
- [x] Eliminar sección Explorar Géneros del Home (dejar solo en Buscador)
- [x] Eliminar filtro Géneros de los chips del Home
- [ ] Compilar y entregar APK

## Fix: Grid de artistas - solo artista principal
- [x] Extraer solo el artista principal (antes de ft., feat., x, &, ,)
- [x] Agrupar reproducciones bajo el mismo artista principal
- [ ] Compilar y entregar APK

## Bugs reportados
- [x] El grid muestra canciones además de artistas (no debería)
- [x] Al seleccionar una canción, se reproduce otra diferente (problema de cola)
- [ ] Compilar y entregar APK

## Indicador visual de canción reproducida
- [x] Marcar con color verde la canción que está siendo reproducida
- [x] Actualizar el indicador cuando cambia la canción
- [ ] Compilar y entregar APK

## Bugs v4.9
- [x] Grid de artistas recientes desapareció del Home
- [x] Botón play/pause siempre muestra pausa (no cambia)
- [x] Verificar que la función _highlightCurrentTrack no rompió nada
- [ ] Compilar y entregar APK

## Bugs v5.0 - CRÍTICO: Selección de canciones incorrecta
- [x] Cuando tocas canción #1, suena #2 (off-by-one bug en playTrack)
- [x] Reescribir playTrack con identificación correcta del elemento clickeado
- [x] Construir cola desde la canción seleccionada hacia adelante
- [x] Compilar y entregar APK v5.1

## Bug v7.1 - Cambio de canción salta a la siguiente
- [x] Mejorar stopAll() para detener completamente HTML5 audio y YouTube player
- [x] Agregar delay en play() para asegurar que se detuvo antes de cargar nueva canción
- [x] Compilar y entregar APK v7.1

## Bug v7.2 - YouTube API agotó cuota
- [x] Reemplazar YouTube Data API con Invidious API (sin límites de cuota)
- [x] Actualizar searchYouTubeTracks para usar Invidious
- [x] Actualizar getTrendingMusic, getPopularLatinMusic, getWorshipMusic
- [x] Probar que el contenido se carga correctamente
- [x] Compilar y entregar APK v7.2
