import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation, Link } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { PlayerProvider } from "./contexts/PlayerContext";
import Sidebar from "./components/Sidebar";
import Player from "./components/Player";
import Home from "./pages/Home";
import SearchPage from "./pages/Search";
import LibraryPage from "./pages/Library";
import ArtistPage from "./pages/Artist";
import AlbumPage from "./pages/Album";
import PlaylistPage from "./pages/Playlist";
import NotFound from "./pages/NotFound";
import UploadPage from "./pages/Upload";
import JamendoArtistPage from "./pages/JamendoArtist";
import JamendoAlbumPage from "./pages/JamendoAlbum";
import GenrePage from "./pages/Genre";
import YouTubeArtistPage from "./pages/YouTubeArtist";
import { Home as HomeIcon, Search, Library } from "lucide-react";

function AppLayout() {
  return (
    <div className="flex flex-col h-screen bg-black overflow-hidden">
      {/* Main area: sidebar + content */}
      <div className="flex flex-1 min-h-0">
        {/* Sidebar - hidden on mobile, shown on md+ */}
        <div className="hidden md:flex">
          <Sidebar />
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-gradient-to-b from-[#1a1a2e] to-[#121212]">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/search" component={SearchPage} />
            <Route path="/library" component={LibraryPage} />
            <Route path="/artist/:id" component={ArtistPage} />
            <Route path="/album/:id" component={AlbumPage} />
            <Route path="/playlist/:id" component={PlaylistPage} />
            <Route path="/upload" component={UploadPage} />
            <Route path="/jamendo-artist/:id" component={JamendoArtistPage} />
            <Route path="/jamendo-album/:id" component={JamendoAlbumPage} />
            <Route path="/genre/:id" component={GenrePage} />
            <Route path="/youtube-artist/:name" component={YouTubeArtistPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>

      {/* Fixed bottom player */}
      <Player />

      {/* Mobile bottom nav */}
      <MobileNav />
    </div>
  );
}

function MobileNav() {
  const [location] = useLocation();

  const items = [
    { href: "/", label: "Inicio", Icon: HomeIcon },
    { href: "/search", label: "Buscar", Icon: Search },
    { href: "/library", label: "Biblioteca", Icon: Library },
  ];

  return (
    <nav className="md:hidden flex border-t border-[#282828] bg-black shrink-0 safe-area-bottom">
      {items.map(({ href, label, Icon }) => {
        const isActive = location === href;
        return (
          <Link
            key={href}
            href={href}
            className={`flex-1 flex flex-col items-center justify-center py-2 transition-colors ${
              isActive ? "text-white" : "text-[#a7a7a7] hover:text-white"
            }`}
          >
            <Icon size={22} strokeWidth={isActive ? 2.5 : 1.5} />
            <span className="text-[10px] mt-1 font-medium">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <PlayerProvider>
          <TooltipProvider>
            <Toaster />
            <AppLayout />
          </TooltipProvider>
        </PlayerProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
