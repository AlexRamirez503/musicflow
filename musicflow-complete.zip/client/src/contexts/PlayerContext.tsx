import React, { createContext, useContext, useRef, useState, useCallback, useEffect } from "react";

export interface Track {
  id: number | string;
  title: string;
  artistId: number | string;
  artistName?: string | null;
  albumId?: number | string | null;
  albumName?: string | null;
  audioUrl: string;
  coverUrl?: string | null;
  duration?: number | null;
  source?: "local" | "jamendo" | "youtube";
  videoId?: string;
}

interface PlayerState {
  currentTrack: Track | null;
  queue: Track[];
  queueIndex: number;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  shuffle: boolean;
  repeat: "none" | "all" | "one";
}

interface PlayerContextValue extends PlayerState {
  play: (track: Track, queue?: Track[]) => void;
  pause: () => void;
  resume: () => void;
  togglePlay: () => void;
  next: () => void;
  prev: () => void;
  seek: (time: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  addToQueue: (track: Track) => void;
}

const PlayerContext = createContext<PlayerContextValue | null>(null);

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

let ytApiLoaded = false;
let ytApiReady = false;
const ytReadyCallbacks: (() => void)[] = [];

function loadYouTubeAPI(): Promise<void> {
  return new Promise((resolve) => {
    if (ytApiReady) { resolve(); return; }
    ytReadyCallbacks.push(resolve);
    if (ytApiLoaded) return;
    ytApiLoaded = true;
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
    window.onYouTubeIframeAPIReady = () => {
      ytApiReady = true;
      ytReadyCallbacks.forEach((cb) => cb());
      ytReadyCallbacks.length = 0;
    };
  });
}

// ── Media Session API helper ──────────────────────────────────────────────
function updateMediaSession(track: Track | null, isPlaying: boolean) {
  if (!("mediaSession" in navigator) || !track) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artistName || "Artista desconocido",
      album: track.albumName || "MusicFlow",
      artwork: track.coverUrl
        ? [
            { src: track.coverUrl, sizes: "96x96", type: "image/jpeg" },
            { src: track.coverUrl, sizes: "128x128", type: "image/jpeg" },
            { src: track.coverUrl, sizes: "256x256", type: "image/jpeg" },
            { src: track.coverUrl, sizes: "512x512", type: "image/jpeg" },
          ]
        : [],
    });
    navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";
  } catch {}
}

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  // Silent audio element that keeps the browser audio session alive
  // This is the KEY trick: a silent audio loop prevents Android from
  // suspending the WebView audio context when the screen is off
  const silentAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioRef = useRef<HTMLAudioElement>(new Audio());
  const ytPlayerRef = useRef<any>(null);
  const ytContainerRef = useRef<HTMLDivElement | null>(null);
  const ytIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const activeSourceRef = useRef<"html5" | "youtube">("html5");
  const stateRef = useRef<PlayerState>({
    currentTrack: null,
    queue: [],
    queueIndex: 0,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.8,
    isMuted: false,
    shuffle: false,
    repeat: "none",
  });

  const [state, setState] = useState<PlayerState>(stateRef.current);

  const updateState = useCallback((updater: (s: PlayerState) => PlayerState) => {
    setState((prev) => {
      const next = updater(prev);
      stateRef.current = next;
      return next;
    });
  }, []);

  // Create a silent audio context to keep the audio session alive on Android
  useEffect(() => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        gainNode.gain.value = 0.001; // Nearly silent
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        oscillator.start();

        // Resume context on user interaction (required by browsers)
        const resumeCtx = () => {
          if (ctx.state === "suspended") ctx.resume();
        };
        document.addEventListener("click", resumeCtx, { once: false });
        document.addEventListener("touchstart", resumeCtx, { once: false });

        return () => {
          document.removeEventListener("click", resumeCtx);
          document.removeEventListener("touchstart", resumeCtx);
          oscillator.stop();
          ctx.close();
        };
      }
    } catch {}
  }, []);

  // Initialize YouTube player (completely hidden, audio only)
  useEffect(() => {
    loadYouTubeAPI().then(() => {
      if (!ytContainerRef.current) return;
      ytPlayerRef.current = new window.YT.Player(ytContainerRef.current, {
        height: "0",
        width: "0",
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          rel: 0,
          showinfo: 0,
          playsinline: 1,
          origin: window.location.origin,
        },
        events: {
          onStateChange: (event: any) => {
            if (activeSourceRef.current !== "youtube") return;
            const YT = window.YT.PlayerState;
            if (event.data === YT.PLAYING) {
              updateState((s) => {
                const dur = ytPlayerRef.current?.getDuration?.() || s.duration;
                updateMediaSession(s.currentTrack, true);
                return { ...s, isPlaying: true, duration: dur };
              });
            } else if (event.data === YT.PAUSED) {
              updateState((s) => {
                updateMediaSession(s.currentTrack, false);
                return { ...s, isPlaying: false };
              });
            } else if (event.data === YT.ENDED) {
              handleTrackEnd();
            }
          },
          onError: () => {
            if (activeSourceRef.current !== "youtube") return;
            console.warn("[Player] YouTube error, skipping...");
            handleNextTrack();
          },
        },
      });
    });

    return () => {
      if (ytIntervalRef.current) clearInterval(ytIntervalRef.current);
    };
  }, []);

  // YouTube time tracking
  useEffect(() => {
    if (ytIntervalRef.current) clearInterval(ytIntervalRef.current);
    ytIntervalRef.current = setInterval(() => {
      if (activeSourceRef.current === "youtube" && ytPlayerRef.current?.getCurrentTime) {
        const ct = ytPlayerRef.current.getCurrentTime() || 0;
        const dur = ytPlayerRef.current.getDuration() || 0;
        updateState((s) => ({ ...s, currentTime: ct, duration: dur }));
      }
    }, 500);
    return () => { if (ytIntervalRef.current) clearInterval(ytIntervalRef.current); };
  }, []);

  // HTML5 audio events
  useEffect(() => {
    const audio = audioRef.current;
    const onTimeUpdate = () => {
      if (activeSourceRef.current !== "html5") return;
      updateState((s) => ({ ...s, currentTime: audio.currentTime }));
    };
    const onDurationChange = () => {
      if (activeSourceRef.current !== "html5") return;
      updateState((s) => ({ ...s, duration: audio.duration || 0 }));
    };
    const onEnded = () => {
      if (activeSourceRef.current !== "html5") return;
      handleTrackEnd();
    };
    const onPlay = () => {
      if (activeSourceRef.current !== "html5") return;
      updateState((s) => {
        updateMediaSession(s.currentTrack, true);
        return { ...s, isPlaying: true };
      });
    };
    const onPause = () => {
      if (activeSourceRef.current !== "html5") return;
      updateState((s) => {
        updateMediaSession(s.currentTrack, false);
        return { ...s, isPlaying: false };
      });
    };
    const onError = () => {
      if (activeSourceRef.current !== "html5") return;
      console.warn("[Player] HTML5 audio error, skipping...");
      handleNextTrack();
    };

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("durationchange", onDurationChange);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("error", onError);
    audio.volume = stateRef.current.volume;

    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("durationchange", onDurationChange);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("error", onError);
    };
  }, []);

  // Media Session action handlers
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const ms = navigator.mediaSession;
    ms.setActionHandler("play", () => resume());
    ms.setActionHandler("pause", () => pause());
    ms.setActionHandler("previoustrack", () => prev());
    ms.setActionHandler("nexttrack", () => next());
    ms.setActionHandler("seekto", (details) => {
      if (details.seekTime != null) seek(details.seekTime);
    });
    return () => {
      ms.setActionHandler("play", null);
      ms.setActionHandler("pause", null);
      ms.setActionHandler("previoustrack", null);
      ms.setActionHandler("nexttrack", null);
      ms.setActionHandler("seekto", null);
    };
  }, []);

  // Prevent page visibility from pausing YouTube
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && stateRef.current.isPlaying && activeSourceRef.current === "youtube") {
        // Try to resume if paused by visibility change
        setTimeout(() => {
          if (ytPlayerRef.current?.getPlayerState?.() === window.YT?.PlayerState?.PAUSED) {
            ytPlayerRef.current.playVideo();
          }
        }, 200);
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  const handleTrackEnd = useCallback(() => {
    const s = stateRef.current;
    if (s.repeat === "one") {
      if (activeSourceRef.current === "youtube" && ytPlayerRef.current) {
        ytPlayerRef.current.seekTo(0);
        ytPlayerRef.current.playVideo();
      } else {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(() => {});
      }
      return;
    }
    const nextIndex = s.shuffle
      ? Math.floor(Math.random() * s.queue.length)
      : s.queueIndex + 1;
    if (nextIndex >= s.queue.length) {
      if (s.repeat === "all" && s.queue.length > 0) {
        playTrackInternal(s.queue[0], s.queue, 0);
      } else {
        updateState((prev) => ({ ...prev, isPlaying: false }));
      }
      return;
    }
    playTrackInternal(s.queue[nextIndex], s.queue, nextIndex);
  }, []);

  const handleNextTrack = useCallback(() => {
    const s = stateRef.current;
    if (s.queue.length <= 1) {
      updateState((prev) => ({ ...prev, isPlaying: false }));
      return;
    }
    const nextIndex = (s.queueIndex + 1) % s.queue.length;
    playTrackInternal(s.queue[nextIndex], s.queue, nextIndex);
  }, []);

  const stopAll = useCallback(() => {
    audioRef.current.pause();
    audioRef.current.src = "";
    if (ytPlayerRef.current?.stopVideo) {
      try { ytPlayerRef.current.stopVideo(); } catch {}
    }
  }, []);

  const playTrackInternal = useCallback((track: Track, queue: Track[], idx: number) => {
    stopAll();

    if (track.source === "youtube" && track.videoId) {
      activeSourceRef.current = "youtube";
      if (ytPlayerRef.current?.loadVideoById) {
        ytPlayerRef.current.loadVideoById(track.videoId);
        ytPlayerRef.current.setVolume(stateRef.current.isMuted ? 0 : stateRef.current.volume * 100);
      }
    } else {
      activeSourceRef.current = "html5";
      audioRef.current.src = track.audioUrl;
      audioRef.current.volume = stateRef.current.volume;
      audioRef.current.muted = stateRef.current.isMuted;
      audioRef.current.play().catch(() => {});
    }

    updateMediaSession(track, true);

    updateState((s) => ({
      ...s,
      currentTrack: track,
      queue,
      queueIndex: idx,
      isPlaying: true,
      currentTime: 0,
    }));
  }, []);

  const play = useCallback((track: Track, queue?: Track[]) => {
    const newQueue = queue ?? [track];
    const idx = newQueue.findIndex((t) => t.id === track.id);
    playTrackInternal(track, newQueue, idx >= 0 ? idx : 0);
  }, []);

  const pause = useCallback(() => {
    if (activeSourceRef.current === "youtube" && ytPlayerRef.current?.pauseVideo) {
      ytPlayerRef.current.pauseVideo();
    } else {
      audioRef.current.pause();
    }
  }, []);

  const resume = useCallback(() => {
    if (activeSourceRef.current === "youtube" && ytPlayerRef.current?.playVideo) {
      ytPlayerRef.current.playVideo();
    } else {
      audioRef.current.play().catch(() => {});
    }
  }, []);

  const togglePlay = useCallback(() => {
    if (stateRef.current.isPlaying) pause();
    else resume();
  }, []);

  const next = useCallback(() => {
    const s = stateRef.current;
    if (s.queue.length === 0) return;
    const nextIndex = s.shuffle
      ? Math.floor(Math.random() * s.queue.length)
      : (s.queueIndex + 1) % s.queue.length;
    playTrackInternal(s.queue[nextIndex], s.queue, nextIndex);
  }, []);

  const prev = useCallback(() => {
    const s = stateRef.current;
    if (activeSourceRef.current === "youtube" && ytPlayerRef.current?.getCurrentTime) {
      if (ytPlayerRef.current.getCurrentTime() > 3) {
        ytPlayerRef.current.seekTo(0);
        return;
      }
    } else if (audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    if (s.queue.length === 0) return;
    const prevIndex = s.queueIndex === 0 ? s.queue.length - 1 : s.queueIndex - 1;
    playTrackInternal(s.queue[prevIndex], s.queue, prevIndex);
  }, []);

  const seek = useCallback((time: number) => {
    if (activeSourceRef.current === "youtube" && ytPlayerRef.current?.seekTo) {
      ytPlayerRef.current.seekTo(time, true);
    } else {
      audioRef.current.currentTime = time;
    }
    updateState((s) => ({ ...s, currentTime: time }));
  }, []);

  const setVolume = useCallback((vol: number) => {
    audioRef.current.volume = vol;
    audioRef.current.muted = false;
    if (ytPlayerRef.current?.setVolume) {
      ytPlayerRef.current.setVolume(vol * 100);
      ytPlayerRef.current.unMute?.();
    }
    updateState((s) => ({ ...s, volume: vol, isMuted: false }));
  }, []);

  const toggleMute = useCallback(() => {
    updateState((s) => {
      const newMuted = !s.isMuted;
      audioRef.current.muted = newMuted;
      if (ytPlayerRef.current) {
        if (newMuted) ytPlayerRef.current.mute?.();
        else ytPlayerRef.current.unMute?.();
      }
      return { ...s, isMuted: newMuted };
    });
  }, []);

  const toggleShuffle = useCallback(() => {
    updateState((s) => ({ ...s, shuffle: !s.shuffle }));
  }, []);

  const toggleRepeat = useCallback(() => {
    updateState((s) => {
      const next = s.repeat === "none" ? "all" : s.repeat === "all" ? "one" : "none";
      return { ...s, repeat: next };
    });
  }, []);

  const addToQueue = useCallback((track: Track) => {
    updateState((s) => ({ ...s, queue: [...s.queue, track] }));
  }, []);

  return (
    <PlayerContext.Provider
      value={{
        ...state,
        play, pause, resume, togglePlay, next, prev, seek,
        setVolume, toggleMute, toggleShuffle, toggleRepeat, addToQueue,
      }}
    >
      {/* YouTube player: positioned off-screen with 1x1 size to keep alive */}
      <div
        aria-hidden="true"
        style={{
          position: "fixed",
          width: 1,
          height: 1,
          overflow: "hidden",
          pointerEvents: "none",
          zIndex: -9999,
          top: -9999,
          left: -9999,
        }}
      >
        <div ref={ytContainerRef} id="yt-player-hidden" />
      </div>
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used within PlayerProvider");
  return ctx;
}
