import { Play, Pause, Heart, MoreHorizontal } from "lucide-react";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { useLocation } from "wouter";

function formatTime(sec: number) {
  if (!sec || isNaN(sec)) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function ArtistLink({ name, source, artistId }: { name: string; source?: string; artistId?: string | number }) {
  const [, navigate] = useLocation();

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (source === "youtube") {
      navigate(`/youtube-artist/${encodeURIComponent(name)}`);
    } else if (source === "jamendo" && artistId) {
      navigate(`/jamendo-artist/${artistId}`);
    } else if (source === "local" && typeof artistId === "number") {
      navigate(`/artist/${artistId}`);
    }
  };

  return (
    <button
      onClick={handleClick}
      className="text-xs text-muted-foreground truncate hover:text-foreground hover:underline text-left block max-w-full"
    >
      {name}
    </button>
  );
}

interface SongRowProps {
  song: Track & { artistName?: string | null; albumTitle?: string | null; duration?: number | null };
  index?: number;
  queue?: Track[];
  showAlbum?: boolean;
  showCover?: boolean;
}

export default function SongRow({ song, index, queue, showAlbum = false, showCover = true }: SongRowProps) {
  const { currentTrack, isPlaying, play, togglePlay } = usePlayer();
  const { isAuthenticated } = useAuth();
  const isActive = currentTrack?.id === song.id;
  const isLocal = song.source !== "jamendo" && typeof song.id === "number";

  const toggleLibrary = trpc.library.toggle.useMutation({
    onSuccess: (data) => toast.success(data.saved ? "Guardado en tu biblioteca" : "Eliminado de tu biblioteca"),
  });
  const { data: isSaved } = trpc.library.check.useQuery(
    { type: "song", itemId: song.id as number },
    { enabled: isAuthenticated && isLocal }
  );

  const handlePlay = () => {
    if (isActive) {
      togglePlay();
    } else {
      play(song, queue ?? [song]);
    }
  };

  return (
    <div
      className={`group flex items-center gap-3 px-4 py-2 rounded-md hover:bg-accent/50 transition-colors cursor-pointer ${isActive ? "bg-accent/30" : ""}`}
      onDoubleClick={handlePlay}
    >
      {/* Index / Play button */}
      <div className="w-8 flex items-center justify-center shrink-0">
        <span className={`text-sm group-hover:hidden ${isActive ? "text-primary" : "text-muted-foreground"}`}>
          {isActive && isPlaying ? (
            <span className="text-primary text-xs">▶</span>
          ) : (
            index !== undefined ? index + 1 : ""
          )}
        </span>
        <button
          onClick={handlePlay}
          className="hidden group-hover:flex items-center justify-center text-foreground"
        >
          {isActive && isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}
        </button>
      </div>

      {/* Cover */}
      {showCover && (
        <img
          src={song.coverUrl ?? `https://picsum.photos/seed/${song.id}/40/40`}
          alt={song.title}
          className="w-10 h-10 rounded object-cover shrink-0"
        />
      )}

      {/* Title + Artist */}
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium truncate ${isActive ? "text-primary" : "text-foreground"}`}>
          {song.title}
        </p>
        <ArtistLink name={song.artistName ?? "Artista"} source={song.source} artistId={song.artistId} />
      </div>

      {/* Album */}
      {showAlbum && (
        <p className="text-sm text-muted-foreground truncate w-40 hidden md:block">{song.albumTitle ?? song.albumName ?? ""}</p>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2 shrink-0">
        {isAuthenticated && isLocal && (
          <button
            onClick={(e) => { e.stopPropagation(); toggleLibrary.mutate({ type: "song", itemId: song.id as number }); }}
            className={`opacity-0 group-hover:opacity-100 transition-all ${isSaved ? "opacity-100 text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Heart size={16} fill={isSaved ? "currentColor" : "none"} />
          </button>
        )}
        <span className="text-xs text-muted-foreground w-10 text-right">{formatTime(song.duration ?? 0)}</span>
      </div>
    </div>
  );
}
