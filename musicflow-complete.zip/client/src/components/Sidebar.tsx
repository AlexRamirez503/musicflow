import { Link, useLocation } from "wouter";
import { Home, Search, Library, Plus, Music2, LogOut, Upload } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { data: playlists } = trpc.playlists.myPlaylists.useQuery(undefined, { enabled: isAuthenticated });
  const [, navigate] = useLocation();
  const createPlaylist = trpc.playlists.create.useMutation({
    onSuccess: (data: any) => {
      const id = data?.insertId;
      if (id) navigate(`/playlist/${id}`);
    },
    onError: () => toast.error("Error al crear la playlist"),
  });

  const handleCreatePlaylist = () => {
    if (!isAuthenticated) { toast.error("Iniciá sesión para crear playlists"); return; }
    createPlaylist.mutate({ name: `Mi Playlist #${(playlists?.length ?? 0) + 1}` });
  };

  const isActive = (href: string) => href === "/" ? location === "/" : location.startsWith(href);

  return (
    <aside className="w-[240px] shrink-0 flex flex-col h-full" style={{ background: "#000000" }}>
      {/* Logo */}
      <div className="px-6 pt-6 pb-5">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "#1db954" }}>
              <Music2 size={18} className="text-black" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">MusicFlow</span>
          </div>
        </Link>
      </div>

      {/* Main navigation */}
      <nav className="px-3 mb-2">
        {[
          { href: "/", icon: Home, label: "Inicio" },
          { href: "/search", icon: Search, label: "Buscar" },
        ].map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div className={`flex items-center gap-4 px-3 py-2.5 rounded-md cursor-pointer mb-0.5 group transition-colors ${
              isActive(href) ? "text-white" : "text-[#b3b3b3] hover:text-white"
            }`}>
              <Icon size={24} strokeWidth={isActive(href) ? 2.5 : 2} />
              <span className="text-sm font-semibold">{label}</span>
            </div>
          </Link>
        ))}
      </nav>

      {/* Library section */}
      <div className="flex-1 flex flex-col min-h-0 mx-2 rounded-lg overflow-hidden" style={{ background: "#121212" }}>
        {/* Library header */}
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <Link href="/library">
            <div className={`flex items-center gap-3 cursor-pointer group transition-colors ${
              isActive("/library") ? "text-white" : "text-[#b3b3b3] hover:text-white"
            }`}>
              <Library size={24} strokeWidth={isActive("/library") ? 2.5 : 2} />
              <span className="text-sm font-semibold">Tu Biblioteca</span>
            </div>
          </Link>
          <button
            onClick={handleCreatePlaylist}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#b3b3b3] hover:text-white hover:bg-[#2a2a2a] transition-colors"
            title="Crear playlist"
          >
            <Plus size={18} />
          </button>
        </div>

        {/* Playlists list */}
        <div className="flex-1 overflow-y-auto px-2 pb-2">
          {/* Upload link */}
          <Link href="/upload">
            <div className={`flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer mb-1 transition-colors ${
              isActive("/upload") ? "bg-[#2a2a2a] text-white" : "text-[#b3b3b3] hover:text-white hover:bg-[#1a1a1a]"
            }`}>
              <div className="w-10 h-10 rounded flex items-center justify-center shrink-0" style={{ background: "#282828" }}>
                <Upload size={16} className="text-[#b3b3b3]" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium truncate text-white">Subir música</p>
                <p className="text-xs text-[#b3b3b3]">Tu archivo</p>
              </div>
            </div>
          </Link>

          {isAuthenticated && playlists && playlists.length > 0 ? (
            playlists.map((pl: any) => (
              <Link key={pl.id} href={`/playlist/${pl.id}`}>
                <div className={`flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer mb-0.5 transition-colors ${
                  location === `/playlist/${pl.id}` ? "bg-[#2a2a2a] text-white" : "text-[#b3b3b3] hover:text-white hover:bg-[#1a1a1a]"
                }`}>
                  <div className="w-10 h-10 rounded shrink-0 overflow-hidden" style={{ background: "#282828" }}>
                    {pl.coverUrl ? (
                      <img src={pl.coverUrl} alt={pl.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Music2 size={16} className="text-[#b3b3b3]" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate text-white">{pl.name}</p>
                    <p className="text-xs text-[#b3b3b3]">Playlist</p>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            !isAuthenticated && (
              <div className="mx-3 mt-2 p-4 rounded-lg" style={{ background: "#282828" }}>
                <p className="text-sm font-bold text-white mb-1">Creá tu primera playlist</p>
                <p className="text-xs text-[#b3b3b3] mb-3">Es fácil, te ayudamos.</p>
                <a
                  href={getLoginUrl()}
                  className="inline-block px-4 py-1.5 rounded-full text-sm font-bold text-black transition-opacity hover:opacity-90"
                  style={{ background: "#ffffff" }}
                >
                  Iniciar sesión
                </a>
              </div>
            )
          )}
        </div>
      </div>

      {/* User section */}
      <div className="p-3 mt-1">
        {isAuthenticated ? (
          <div className="flex items-center gap-2 px-2 py-2 rounded-md hover:bg-[#1a1a1a] transition-colors cursor-pointer group">
            <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-black text-xs font-bold" style={{ background: "#1db954" }}>
              {(user?.name ?? "U")[0].toUpperCase()}
            </div>
            <span className="text-sm font-semibold text-white truncate flex-1">{user?.name ?? "Usuario"}</span>
            <button
              onClick={logout}
              className="opacity-0 group-hover:opacity-100 text-[#b3b3b3] hover:text-white transition-all"
              title="Cerrar sesión"
            >
              <LogOut size={14} />
            </button>
          </div>
        ) : null}
      </div>
    </aside>
  );
}
