import { usePlayer } from "@/contexts/PlayerContext";
import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1,
  Volume2, VolumeX, Volume1, Heart, ListMusic,
} from "lucide-react";
import { useCallback, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

function formatTime(sec: number) {
  if (!sec || isNaN(sec)) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function VolumeIcon({ volume, muted }: { volume: number; muted: boolean }) {
  if (muted || volume === 0) return <VolumeX size={18} />;
  if (volume < 0.5) return <Volume1 size={18} />;
  return <Volume2 size={18} />;
}

export default function Player() {
  const {
    currentTrack, isPlaying, currentTime, duration, volume, isMuted,
    shuffle, repeat, togglePlay, next, prev, seek, setVolume, toggleMute,
    toggleShuffle, toggleRepeat,
  } = usePlayer();

  const { isAuthenticated } = useAuth();
  const isLocal = currentTrack?.source !== "jamendo" && typeof currentTrack?.id === "number";
  const playMutation = trpc.songs.play.useMutation();
  const toggleLibrary = trpc.library.toggle.useMutation();
  const { data: isSaved } = trpc.library.check.useQuery(
    { type: "song", itemId: (currentTrack?.id ?? 0) as number },
    { enabled: isAuthenticated && !!currentTrack && isLocal }
  );

  const progressRef = useRef<HTMLInputElement>(null);
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    seek((parseFloat(e.target.value) / 100) * duration);
  }, [seek, duration]);

  const handleTogglePlay = useCallback(() => {
    if (currentTrack && !isPlaying && isLocal) {
      playMutation.mutate({ id: currentTrack.id as number });
    }
    togglePlay();
  }, [currentTrack, isPlaying, isLocal, togglePlay, playMutation]);

  if (!currentTrack) {
    return (
      <div className="h-20 border-t border-border bg-[var(--player-bg,#181818)] flex items-center justify-center px-4">
        <p className="text-muted-foreground text-sm">Seleccioná una canción para reproducir</p>
      </div>
    );
  }

  return (
    <div className="h-20 border-t border-border bg-[#181818] flex items-center px-4 gap-4 select-none shrink-0">
      {/* Track info */}
      <div className="flex items-center gap-3 w-[220px] min-w-0 shrink-0">
        <img
          src={currentTrack.coverUrl ?? `https://picsum.photos/seed/${currentTrack.id}/56/56`}
          alt={currentTrack.title}
          className="w-14 h-14 rounded object-cover shrink-0"
        />
        <div className="min-w-0">
          <p className="text-sm font-medium text-foreground truncate">{currentTrack.title}</p>
          <p className="text-xs text-muted-foreground truncate">{currentTrack.artistName ?? "Artista"}</p>
        </div>
        {isAuthenticated && isLocal && (
          <button
            onClick={() => toggleLibrary.mutate({ type: "song", itemId: currentTrack.id as number })}
            className={`shrink-0 transition-colors ${isSaved ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Heart size={16} fill={isSaved ? "currentColor" : "none"} />
          </button>
        )}
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center gap-1 flex-1 min-w-0">
        <div className="flex items-center gap-4">
          <button
            onClick={toggleShuffle}
            className={`transition-colors ${shuffle ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Shuffle size={18} />
          </button>
          <button onClick={prev} className="text-muted-foreground hover:text-foreground transition-colors">
            <SkipBack size={22} fill="currentColor" />
          </button>
          <button
            onClick={handleTogglePlay}
            className="w-9 h-9 rounded-full bg-white flex items-center justify-center text-black hover:scale-105 transition-transform"
          >
            {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
          </button>
          <button onClick={next} className="text-muted-foreground hover:text-foreground transition-colors">
            <SkipForward size={22} fill="currentColor" />
          </button>
          <button
            onClick={toggleRepeat}
            className={`transition-colors ${repeat !== "none" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            {repeat === "one" ? <Repeat1 size={18} /> : <Repeat size={18} />}
          </button>
        </div>

        {/* Progress bar */}
        <div className="flex items-center gap-2 w-full max-w-lg">
          <span className="text-xs text-muted-foreground w-8 text-right shrink-0">{formatTime(currentTime)}</span>
          <div className="relative flex-1 h-1 group">
            <input
              ref={progressRef}
              type="range"
              min={0}
              max={100}
              value={progress}
              onChange={handleSeek}
              className="w-full h-1 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, var(--color-primary, #1db954) ${progress}%, oklch(0.35 0.005 264) ${progress}%)`,
              }}
            />
          </div>
          <span className="text-xs text-muted-foreground w-8 shrink-0">{formatTime(duration)}</span>
        </div>
      </div>

      {/* Volume */}
      <div className="flex items-center gap-2 w-[180px] shrink-0 justify-end">
        <button onClick={toggleMute} className="text-muted-foreground hover:text-foreground transition-colors">
          <VolumeIcon volume={volume} muted={isMuted} />
        </button>
        <input
          type="range"
          min={0}
          max={100}
          value={isMuted ? 0 : Math.round(volume * 100)}
          onChange={(e) => setVolume(parseFloat(e.target.value) / 100)}
          className="w-24 h-1 rounded-full appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, white ${isMuted ? 0 : Math.round(volume * 100)}%, oklch(0.35 0.005 264) ${isMuted ? 0 : Math.round(volume * 100)}%)`,
          }}
        />
      </div>
    </div>
  );
}
