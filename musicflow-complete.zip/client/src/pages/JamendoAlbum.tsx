import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Play, Pause, ArrowLeft, Clock } from "lucide-react";
import { useParams, Link } from "wouter";
import SongRow from "@/components/SongRow";

function mapJamendoTrack(t: any): Track {
  return {
    id: t.id,
    title: t.name,
    artistId: t.artist_id,
    artistName: t.artist_name,
    albumId: t.album_id,
    albumName: t.album_name,
    audioUrl: t.audio,
    coverUrl: t.album_image || t.image,
    duration: t.duration,
    source: "jamendo",
  };
}

export default function JamendoAlbum() {
  const params = useParams<{ id: string }>();
  const albumId = params.id ?? "";

  const { data: album, isLoading: loadingAlbum } = trpc.jamendo.album.useQuery(
    { albumId },
    { enabled: !!albumId }
  );
  const { data: tracks, isLoading: loadingTracks } = trpc.jamendo.albumTracks.useQuery(
    { albumId },
    { enabled: !!albumId }
  );

  const { play, currentTrack, isPlaying, togglePlay } = usePlayer();
  const mappedTracks = (tracks ?? []).map(mapJamendoTrack);
  const isPlayingAlbum = mappedTracks.some((t) => t.id === currentTrack?.id);

  const totalDuration = mappedTracks.reduce((acc, t) => acc + (t.duration ?? 0), 0);
  const totalMinutes = Math.floor(totalDuration / 60);

  const handlePlayAll = () => {
    if (isPlayingAlbum) {
      togglePlay();
    } else if (mappedTracks.length > 0) {
      play(mappedTracks[0], mappedTracks);
    }
  };

  if (loadingAlbum) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-[#1db954] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!album) {
    return (
      <div className="text-center py-16 text-[#a7a7a7]">
        <p>Álbum no encontrado</p>
        <Link href="/" className="text-[#1db954] mt-2 inline-block">Volver al inicio</Link>
      </div>
    );
  }

  return (
    <div className="pb-32">
      {/* Hero */}
      <div className="flex flex-col md:flex-row items-center md:items-end gap-6 p-6 bg-gradient-to-b from-[#535353] to-[#121212]">
        <Link href="/" className="absolute top-4 left-4 w-8 h-8 rounded-full bg-black/50 flex items-center justify-center md:hidden">
          <ArrowLeft size={18} className="text-white" />
        </Link>
        <img
          src={album.image || `https://picsum.photos/seed/album-${album.id}/300/300`}
          alt={album.name}
          className="w-48 h-48 md:w-56 md:h-56 rounded shadow-2xl object-cover shrink-0"
        />
        <div className="text-center md:text-left">
          <p className="text-xs text-white/70 uppercase tracking-wider mb-1">Álbum</p>
          <h1 className="text-3xl md:text-5xl font-black text-white mb-3">{album.name}</h1>
          <div className="flex items-center gap-2 text-sm text-[#a7a7a7] justify-center md:justify-start flex-wrap">
            <Link href={`/jamendo-artist/${album.artist_id}`} className="text-white font-bold hover:underline">
              {album.artist_name}
            </Link>
            {album.releasedate && (
              <>
                <span>·</span>
                <span>{new Date(album.releasedate).getFullYear()}</span>
              </>
            )}
            <span>·</span>
            <span>{mappedTracks.length} canciones, {totalMinutes} min</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="px-6 py-4 flex items-center gap-4">
        <button
          onClick={handlePlayAll}
          className="w-14 h-14 rounded-full bg-[#1db954] flex items-center justify-center shadow-xl hover:scale-105 transition-transform"
        >
          {isPlayingAlbum && isPlaying ? (
            <Pause size={28} fill="black" className="text-black" />
          ) : (
            <Play size={28} fill="black" className="text-black ml-1" />
          )}
        </button>
      </div>

      {/* Track list */}
      <div className="px-6">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-2 border-b border-[#ffffff12] text-xs text-[#a7a7a7] uppercase tracking-wider mb-2">
          <span className="w-8 text-center">#</span>
          <span className="flex-1">Título</span>
          <Clock size={14} />
        </div>

        {loadingTracks ? (
          <div className="space-y-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="animate-pulse flex items-center gap-3 px-4 py-2">
                <div className="w-8 h-4 bg-[#282828] rounded" />
                <div className="flex-1">
                  <div className="h-3 bg-[#282828] rounded w-1/3 mb-2" />
                  <div className="h-3 bg-[#282828] rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : mappedTracks.length > 0 ? (
          <div className="space-y-0.5">
            {mappedTracks.map((track, i) => (
              <SongRow
                key={track.id}
                song={{ ...track, albumTitle: album.name }}
                index={i}
                queue={mappedTracks}
                showCover={false}
              />
            ))}
          </div>
        ) : (
          <p className="text-[#a7a7a7] text-sm py-4">No se encontraron canciones en este álbum.</p>
        )}
      </div>
    </div>
  );
}
