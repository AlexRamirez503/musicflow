import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Search, Music2, Mic2, Disc3, Loader2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useDebounce } from "@/hooks/useDebounce";

function ytToTrack(yt: any): Track {
  return {
    id: yt.id,
    title: yt.title,
    artistId: yt.channelId || "",
    artistName: yt.artist,
    audioUrl: "",
    coverUrl: yt.thumbnailLarge || yt.thumbnail,
    duration: yt.durationSeconds || null,
    source: "youtube",
    videoId: yt.videoId,
  };
}

function jamendoToTrack(t: any): Track {
  return {
    id: t.id,
    title: t.name,
    artistId: t.artist_id,
    artistName: t.artist_name,
    albumId: t.album_id,
    albumName: t.album_name,
    audioUrl: t.audio,
    coverUrl: t.album_image || t.image,
    duration: t.duration,
    source: "jamendo",
  };
}

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 400);
  const hasQuery = debouncedQuery.trim().length > 0;

  // YouTube search (primary)
  const { data: ytResults, isLoading: ytLoading } = trpc.youtube.search.useQuery(
    { q: debouncedQuery },
    { enabled: hasQuery }
  );

  // Jamendo search (secondary)
  const { data: jamendoResults, isLoading: jamendoLoading } = trpc.jamendo.search.useQuery(
    { q: debouncedQuery, limit: 10 },
    { enabled: hasQuery }
  );

  // Local DB search
  const { data: localResults } = trpc.search.query.useQuery(
    { q: debouncedQuery },
    { enabled: hasQuery }
  );

  // YouTube genres for browsing
  const { data: genresData } = trpc.youtube.genres.useQuery();

  const { play } = usePlayer();
  const isLoading = ytLoading || jamendoLoading;

  const ytTracks = useMemo(() => (ytResults || []).map(ytToTrack), [ytResults]);
  const jamendoTracks = useMemo(() => (jamendoResults?.tracks ?? []).map(jamendoToTrack), [jamendoResults]);

  const localSongs = useMemo(() => (localResults?.songs ?? []).map((s: any): Track => ({
    id: s.id,
    title: s.title,
    artistId: s.artistId,
    artistName: s.artistName,
    albumId: s.albumId,
    audioUrl: s.audioUrl,
    coverUrl: s.coverUrl,
    duration: s.duration,
    source: "local",
  })), [localResults]);

  const allTracks = useMemo(() => [...ytTracks, ...jamendoTracks, ...localSongs], [ytTracks, jamendoTracks, localSongs]);

  // Extract unique YouTube artists from search results
  const ytArtists = useMemo(() => {
    const seen = new Set<string>();
    const artists: { name: string; thumbnail: string }[] = [];
    for (const t of (ytResults || [])) {
      const name = (t as any).artist || "";
      if (name && !seen.has(name)) {
        seen.add(name);
        artists.push({ name, thumbnail: (t as any).thumbnailLarge || (t as any).thumbnail || "" });
      }
    }
    return artists.slice(0, 6);
  }, [ytResults]);

  const jamendoArtists = jamendoResults?.artists ?? [];
  const jamendoAlbums = jamendoResults?.albums ?? [];
  const hasResults = allTracks.length > 0 || jamendoArtists.length > 0 || jamendoAlbums.length > 0 || ytArtists.length > 0;

  const genres = genresData || [];

  return (
    <div className="px-4 md:px-6 py-6 pb-32">
      <h1 className="text-2xl md:text-3xl font-bold text-white mb-6">Buscar</h1>

      {/* Search input */}
      <div className="relative mb-8 max-w-xl">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#a7a7a7]" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Artistas, canciones o álbumes"
          className="w-full pl-11 pr-10 py-3 rounded-full bg-white text-black placeholder:text-[#757575] focus:outline-none focus:ring-2 focus:ring-white text-sm font-medium"
          autoFocus
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-[#757575] hover:text-black text-lg leading-none"
          >
            ×
          </button>
        )}
      </div>

      {/* Results */}
      {hasQuery ? (
        isLoading ? (
          <div className="flex items-center gap-3 text-[#a7a7a7] py-8">
            <Loader2 className="w-5 h-5 text-[#1db954] animate-spin" />
            <span>Buscando música...</span>
          </div>
        ) : hasResults ? (
          <div className="space-y-8">
            {/* YouTube Artists extracted from results */}
            {ytArtists.length > 0 && (
              <section>
                <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Mic2 size={18} /> Artistas
                </h2>
                <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                  {ytArtists.map((artist) => (
                    <Link key={artist.name} href={`/youtube-artist/${encodeURIComponent(artist.name)}`}>
                      <div className="flex flex-col items-center gap-2 w-28 shrink-0 cursor-pointer group">
                        <div className="w-20 h-20 rounded-full overflow-hidden bg-[#282828] shadow-lg group-hover:ring-2 group-hover:ring-[#1db954] transition-all">
                          {artist.thumbnail ? (
                            <img src={artist.thumbnail} alt={artist.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Mic2 size={28} className="text-[#535353]" />
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-white font-medium text-center truncate w-full">{artist.name}</p>
                        <p className="text-[10px] text-[#a7a7a7]">Artista</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* YouTube tracks (primary) */}
            {ytTracks.length > 0 && (
              <section>
                <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Music2 size={18} /> Canciones
                </h2>
                <div className="space-y-1">
                  {ytTracks.map((track) => (
                    <div
                      key={track.id}
                      onClick={() => play(track, allTracks)}
                      className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[#ffffff12] cursor-pointer transition-colors"
                    >
                      <img
                        src={track.coverUrl || ""}
                        alt={track.title}
                        className="w-10 h-10 rounded object-cover shrink-0 bg-[#282828]"
                        loading="lazy"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{track.title}</p>
                        <Link
                          href={`/youtube-artist/${encodeURIComponent(track.artistName || "")}`}
                          onClick={(e: React.MouseEvent) => e.stopPropagation()}
                          className="text-xs text-[#a7a7a7] truncate hover:text-white hover:underline block"
                        >
                          {track.artistName}
                        </Link>
                      </div>
                      {track.duration ? (
                        <span className="text-xs text-[#a7a7a7]">
                          {Math.floor(track.duration / 60)}:{String(Math.floor(track.duration % 60)).padStart(2, "0")}
                        </span>
                      ) : null}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Jamendo tracks */}
            {jamendoTracks.length > 0 && (
              <section>
                <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Music2 size={18} /> Música Independiente
                </h2>
                <div className="space-y-1">
                  {jamendoTracks.map((track) => (
                    <div
                      key={`j-${track.id}`}
                      onClick={() => play(track, allTracks)}
                      className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[#ffffff12] cursor-pointer transition-colors"
                    >
                      <img
                        src={track.coverUrl || ""}
                        alt={track.title}
                        className="w-10 h-10 rounded object-cover shrink-0 bg-[#282828]"
                        loading="lazy"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{track.title}</p>
                        <p className="text-xs text-[#a7a7a7] truncate">{track.artistName}</p>
                      </div>
                      {track.duration ? (
                        <span className="text-xs text-[#a7a7a7]">
                          {Math.floor(track.duration / 60)}:{String(Math.floor(track.duration % 60)).padStart(2, "0")}
                        </span>
                      ) : null}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Jamendo Artists */}
            {jamendoArtists.length > 0 && (
              <section>
                <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Mic2 size={18} /> Artistas
                </h2>
                <div className="space-y-1">
                  {jamendoArtists.map((artist: any) => (
                    <Link key={artist.id} href={`/jamendo-artist/${artist.id}`}>
                      <div className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[#ffffff12] cursor-pointer transition-colors">
                        <img
                          src={artist.image || ""}
                          alt={artist.name}
                          className="w-10 h-10 rounded-full object-cover shrink-0 bg-[#282828]"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white truncate">{artist.name}</p>
                          <p className="text-xs text-[#a7a7a7]">Artista</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Jamendo Albums */}
            {jamendoAlbums.length > 0 && (
              <section>
                <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Disc3 size={18} /> Álbumes
                </h2>
                <div className="space-y-1">
                  {jamendoAlbums.map((album: any) => (
                    <Link key={album.id} href={`/jamendo-album/${album.id}`}>
                      <div className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[#ffffff12] cursor-pointer transition-colors">
                        <img
                          src={album.image || ""}
                          alt={album.name}
                          className="w-10 h-10 rounded object-cover shrink-0 bg-[#282828]"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white truncate">{album.name}</p>
                          <p className="text-xs text-[#a7a7a7]">Álbum · {album.artist_name}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        ) : (
          <div className="text-center py-16 text-[#a7a7a7]">
            <Search size={48} className="mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium text-white">No se encontraron resultados para "{debouncedQuery}"</p>
            <p className="text-sm mt-2">Intentá con otro nombre de canción, artista o álbum.</p>
          </div>
        )
      ) : (
        /* Browse genres */
        <div>
          <h2 className="text-lg font-bold text-white mb-4">Explorar géneros</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {genres.map((genre: any) => (
              <button
                key={genre.id}
                onClick={() => setQuery(genre.name)}
                className="rounded-lg p-4 text-left hover:opacity-90 transition-opacity relative overflow-hidden h-24"
                style={{ backgroundColor: genre.color }}
              >
                <span className="text-white font-bold text-sm">{genre.name}</span>
                <span className="absolute bottom-2 right-3 text-3xl opacity-80">{genre.icon}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
