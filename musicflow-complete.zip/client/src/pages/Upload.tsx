import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Upload, Music2, Image, CheckCircle2, AlertCircle, X } from "lucide-react";
import { toast } from "sonner";

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function UploadPage() {
  const { isAuthenticated } = useAuth();
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [artistName, setArtistName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [done, setDone] = useState(false);
  const audioRef = useRef<HTMLInputElement>(null);
  const coverRef = useRef<HTMLInputElement>(null);

  const { data: artists } = trpc.artists.list.useQuery();

  const uploadAudio = trpc.upload.audio.useMutation();
  const uploadImage = trpc.upload.image.useMutation();
  const createArtist = trpc.artists.create.useMutation();
  const createSong = trpc.songs.create.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-24 px-6 text-center">
        <Upload size={64} className="text-muted-foreground mb-6 opacity-40" />
        <h2 className="text-2xl font-bold text-foreground mb-3">Subir música</h2>
        <p className="text-muted-foreground mb-6 max-w-sm">
          Iniciá sesión para subir tus propios archivos de audio a MusicFlow.
        </p>
        <a
          href={getLoginUrl()}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-full font-semibold hover:opacity-90 transition-opacity"
        >
          Iniciar sesión
        </a>
      </div>
    );
  }

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-24 px-6 text-center">
        <CheckCircle2 size={64} className="text-primary mb-6" />
        <h2 className="text-2xl font-bold text-foreground mb-3">¡Canción subida!</h2>
        <p className="text-muted-foreground mb-6">Tu canción ya está disponible en la app.</p>
        <button
          onClick={() => { setDone(false); setTitle(""); setArtistName(""); setAudioFile(null); setCoverFile(null); }}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-full font-semibold hover:opacity-90 transition-opacity"
        >
          Subir otra canción
        </button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!audioFile || !title.trim() || !artistName.trim()) {
      toast.error("Completá todos los campos obligatorios");
      return;
    }

    setUploading(true);
    try {
      // Upload audio
      const audioBase64 = await fileToBase64(audioFile);
      const { url: audioUrl } = await uploadAudio.mutateAsync({
        fileName: audioFile.name,
        fileBase64: audioBase64,
        mimeType: audioFile.type,
      });

      // Upload cover if provided
      let coverUrl: string | undefined;
      if (coverFile) {
        const coverBase64 = await fileToBase64(coverFile);
        const { url } = await uploadImage.mutateAsync({
          fileName: coverFile.name,
          fileBase64: coverBase64,
          mimeType: coverFile.type,
        });
        coverUrl = url;
      }

      // Find or create artist
      let artistId: number;
      const existing = artists?.find((a) => a.name.toLowerCase() === artistName.trim().toLowerCase());
      if (existing) {
        artistId = existing.id;
      } else {
        const result = await createArtist.mutateAsync({ name: artistName.trim() });
        artistId = (result as any).insertId;
      }

      // Create song
      await createSong.mutateAsync({
        title: title.trim(),
        artistId,
        audioUrl,
        coverUrl,
      });

      setDone(true);
      toast.success("Canción subida correctamente");
    } catch (err: any) {
      toast.error(err?.message ?? "Error al subir la canción");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="px-6 py-6 max-w-xl">
      <h1 className="text-3xl font-bold text-foreground mb-2">Subir música</h1>
      <p className="text-muted-foreground mb-8 text-sm">
        Subí tus propios archivos de audio (MP3 o WAV) a MusicFlow.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Audio file */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Archivo de audio <span className="text-destructive">*</span>
          </label>
          <div
            onClick={() => audioRef.current?.click()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              audioFile ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
            }`}
          >
            {audioFile ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Music2 size={20} className="text-primary" />
                  <span className="text-sm text-foreground truncate max-w-[200px]">{audioFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setAudioFile(null); }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <>
                <Music2 size={32} className="mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Tocá para seleccionar un archivo MP3 o WAV</p>
                <p className="text-xs text-muted-foreground mt-1">Máximo 16 MB</p>
              </>
            )}
          </div>
          <input
            ref={audioRef}
            type="file"
            accept="audio/mpeg,audio/wav,audio/mp3"
            className="hidden"
            onChange={(e) => setAudioFile(e.target.files?.[0] ?? null)}
          />
        </div>

        {/* Cover image */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Portada <span className="text-muted-foreground font-normal">(opcional)</span>
          </label>
          <div
            onClick={() => coverRef.current?.click()}
            className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
              coverFile ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
            }`}
          >
            {coverFile ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={URL.createObjectURL(coverFile)}
                    alt="preview"
                    className="w-10 h-10 rounded object-cover"
                  />
                  <span className="text-sm text-foreground truncate max-w-[200px]">{coverFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setCoverFile(null); }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <>
                <Image size={24} className="mx-auto mb-1 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">JPG, PNG o WebP</p>
              </>
            )}
          </div>
          <input
            ref={coverRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => setCoverFile(e.target.files?.[0] ?? null)}
          />
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Título de la canción <span className="text-destructive">*</span>
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Nombre de la canción"
            className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            required
          />
        </div>

        {/* Artist */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Artista <span className="text-destructive">*</span>
          </label>
          <input
            type="text"
            value={artistName}
            onChange={(e) => setArtistName(e.target.value)}
            placeholder="Nombre del artista"
            list="artists-list"
            className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            required
          />
          <datalist id="artists-list">
            {artists?.map((a) => <option key={a.id} value={a.name} />)}
          </datalist>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={uploading || !audioFile || !title.trim() || !artistName.trim()}
          className="w-full bg-primary text-primary-foreground py-3 rounded-full font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {uploading ? (
            <>
              <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
              Subiendo...
            </>
          ) : (
            <>
              <Upload size={18} />
              Subir canción
            </>
          )}
        </button>
      </form>
    </div>
  );
}
