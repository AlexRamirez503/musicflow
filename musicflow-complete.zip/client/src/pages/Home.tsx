import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Play, Pause, Music2, Loader2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useMemo } from "react";

// ── Helpers ──────────────────────────────────────────────────────────────────

function ytToTrack(yt: any): Track {
  return {
    id: yt.id,
    title: yt.title,
    artistId: yt.channelId || "",
    artistName: yt.artist,
    audioUrl: "",
    coverUrl: yt.thumbnailLarge || yt.thumbnail,
    duration: yt.durationSeconds || null,
    source: "youtube",
    videoId: yt.videoId,
  };
}

function jamendoToTrack(t: any): Track {
  return {
    id: t.id,
    title: t.name,
    artistId: t.artist_id,
    artistName: t.artist_name,
    albumId: t.album_id,
    albumName: t.album_name,
    audioUrl: t.audio,
    coverUrl: t.album_image || t.image,
    duration: t.duration,
    source: "jamendo",
  };
}

// ── Components ───────────────────────────────────────────────────────────────

function TrackCard({ track, queue }: { track: Track; queue: Track[] }) {
  const { currentTrack, isPlaying, play, togglePlay } = usePlayer();
  const isActive = currentTrack?.id === track.id;

  return (
    <div
      className="group relative bg-[#181818] hover:bg-[#282828] rounded-md p-3 transition-all cursor-pointer flex-shrink-0 w-[155px] md:w-auto"
      onClick={() => (isActive ? togglePlay() : play(track, queue))}
    >
      <div className="relative mb-3">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt={track.title} className="w-full aspect-square object-cover rounded-md shadow-lg" loading="lazy" />
        ) : (
          <div className="w-full aspect-square rounded-md bg-[#282828] flex items-center justify-center">
            <Music2 className="w-10 h-10 text-[#535353]" />
          </div>
        )}
        <button
          className={`absolute bottom-2 right-2 w-12 h-12 rounded-full bg-[#1db954] flex items-center justify-center shadow-xl transition-all ${
            isActive ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0"
          }`}
        >
          {isActive && isPlaying ? (
            <Pause size={24} fill="black" className="text-black" />
          ) : (
            <Play size={24} fill="black" className="text-black ml-1" />
          )}
        </button>
      </div>
      <p className="text-sm font-bold text-white truncate">{track.title}</p>
      <p className="text-xs text-[#a7a7a7] truncate mt-1">{track.artistName}</p>
    </div>
  );
}

function ArtistChip({ name }: { name: string }) {
  const [, navigate] = useLocation();

  return (
    <button
      onClick={() => navigate(`/youtube-artist/${encodeURIComponent(name)}`)}
      className="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap bg-[#282828] text-white hover:bg-[#3e3e3e]"
    >
      {name}
    </button>
  );
}

function GenreCard({ genre }: { genre: { id: string; name: string; color: string; icon: string } }) {
  return (
    <Link href={`/genre/${genre.id}`}>
      <div
        className="relative flex-shrink-0 w-[155px] h-[95px] rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform"
        style={{ backgroundColor: genre.color }}
      >
        <div className="p-3 h-full flex flex-col justify-between">
          <span className="text-2xl">{genre.icon}</span>
          <p className="text-sm font-bold text-white">{genre.name}</p>
        </div>
      </div>
    </Link>
  );
}

function HScrollSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-xl md:text-2xl font-bold text-white mb-4">{title}</h2>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">{children}</div>
    </section>
  );
}

function GridSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="text-xl md:text-2xl font-bold text-white mb-4">{title}</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">{children}</div>
    </section>
  );
}

function LoadingSection({ title }: { title: string }) {
  return (
    <section className="mb-8">
      <h2 className="text-xl md:text-2xl font-bold text-white mb-4">{title}</h2>
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-[#1db954] animate-spin" />
      </div>
    </section>
  );
}

function QuickPlayCard({ track, queue }: { track: Track; queue: Track[] }) {
  const { currentTrack, isPlaying, play, togglePlay } = usePlayer();
  const isActive = currentTrack?.id === track.id;

  return (
    <div
      className="group flex items-center bg-[#ffffff12] hover:bg-[#ffffff26] rounded overflow-hidden cursor-pointer transition-colors"
      onClick={() => (isActive ? togglePlay() : play(track, queue))}
    >
      <img
        src={track.coverUrl ?? `https://picsum.photos/seed/${track.id}/80/80`}
        alt={track.title}
        className="w-16 h-16 object-cover shrink-0"
        loading="lazy"
      />
      <span className="text-sm font-bold text-white px-3 truncate flex-1">{track.title}</span>
      <div
        className={`w-10 h-10 rounded-full bg-[#1db954] flex items-center justify-center mr-3 shadow-lg transition-all ${
          isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
        }`}
      >
        {isActive && isPlaying ? (
          <Pause size={18} fill="black" className="text-black" />
        ) : (
          <Play size={18} fill="black" className="text-black ml-0.5" />
        )}
      </div>
    </div>
  );
}

// ── Quick artist list ────────────────────────────────────────────────────────

const QUICK_ARTISTS = [
  "Jesús Adrián Romero",
  "Bad Bunny",
  "Shakira",
  "Christian Nodal",
  "Peso Pluma",
  "Karol G",
  "Ozuna",
  "Marcos Witt",
  "Daddy Yankee",
  "Luis Miguel",
];

// ── Main Page ────────────────────────────────────────────────────────────────

export default function Home() {
  const { isAuthenticated } = useAuth();

  // YouTube queries
  const { data: ytPopular, isLoading: ytPopularLoading } = trpc.youtube.popularLatin.useQuery();
  const { data: ytWorship, isLoading: ytWorshipLoading } = trpc.youtube.worship.useQuery();
  const { data: ytTrending, isLoading: ytTrendingLoading } = trpc.youtube.trending.useQuery();
  const { data: genresData } = trpc.youtube.genres.useQuery();

  // Jamendo queries (secondary)
  const { data: jamendoPopular } = trpc.jamendo.popularLatin.useQuery({ limit: 12 });
  const { data: playlists } = trpc.playlists.myPlaylists.useQuery(undefined, { enabled: isAuthenticated });

  // Convert to Track format
  const popularTracks = useMemo(() => (ytPopular || []).map(ytToTrack), [ytPopular]);
  const worshipTracks = useMemo(() => (ytWorship || []).map(ytToTrack), [ytWorship]);
  const trendingTracks = useMemo(() => (ytTrending || []).map(ytToTrack), [ytTrending]);
  const jamendoTracks = useMemo(() => (jamendoPopular || []).map(jamendoToTrack), [jamendoPopular]);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Buenos días";
    if (h < 18) return "Buenas tardes";
    return "Buenas noches";
  })();

  return (
    <div className="p-4 md:p-6 pb-32 overflow-y-auto">
      {/* Header with gradient */}
      <div className="bg-gradient-to-b from-[#1db954]/20 to-transparent -mx-4 md:-mx-6 -mt-4 pt-6 pb-4 px-4 md:px-6 mb-2">
        <h1 className="text-2xl md:text-3xl font-bold text-white">{greeting}</h1>
      </div>

      {/* Quick artist chips - navigate to artist profile */}
      <section className="mb-6">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {QUICK_ARTISTS.map((name) => (
            <ArtistChip key={name} name={name} />
          ))}
        </div>
      </section>

      {/* Quick play grid (top trending) */}
      {trendingTracks.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-8">
          {trendingTracks.slice(0, 6).map((track) => (
            <QuickPlayCard key={track.id} track={track} queue={trendingTracks} />
          ))}
        </div>
      )}

      {/* Genres */}
      {genresData && (
        <HScrollSection title="Explorar Géneros">
          {genresData.map((g: any) => (
            <GenreCard key={g.id} genre={g} />
          ))}
        </HScrollSection>
      )}

      {/* Trending Latin */}
      {ytTrendingLoading ? (
        <LoadingSection title="Tendencias Latinas" />
      ) : trendingTracks.length > 0 ? (
        <GridSection title="Tendencias Latinas">
          {trendingTracks.map((t) => (
            <TrackCard key={t.id} track={t} queue={trendingTracks} />
          ))}
        </GridSection>
      ) : null}

      {/* Popular Latin */}
      {ytPopularLoading ? (
        <LoadingSection title="Éxitos Latinos" />
      ) : popularTracks.length > 0 ? (
        <GridSection title="Éxitos Latinos">
          {popularTracks.map((t) => (
            <TrackCard key={t.id} track={t} queue={popularTracks} />
          ))}
        </GridSection>
      ) : null}

      {/* Worship / Alabanza */}
      {ytWorshipLoading ? (
        <LoadingSection title="Alabanza y Adoración" />
      ) : worshipTracks.length > 0 ? (
        <GridSection title="Alabanza y Adoración">
          {worshipTracks.map((t) => (
            <TrackCard key={t.id} track={t} queue={worshipTracks} />
          ))}
        </GridSection>
      ) : null}

      {/* Jamendo indie tracks */}
      {jamendoTracks.length > 0 && (
        <GridSection title="Música Independiente">
          {jamendoTracks.map((t) => (
            <TrackCard key={t.id} track={t} queue={jamendoTracks} />
          ))}
        </GridSection>
      )}

      {/* User playlists */}
      {isAuthenticated && playlists && playlists.length > 0 && (
        <section className="mb-8">
          <h2 className="text-xl md:text-2xl font-bold text-white mb-4">Tus Playlists</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {playlists.slice(0, 8).map((pl: any) => (
              <Link key={pl.id} href={`/playlist/${pl.id}`}>
                <div className="group bg-[#181818] hover:bg-[#282828] rounded-md p-3 transition-all cursor-pointer">
                  <div className="w-full aspect-square rounded-md mb-3 bg-[#282828] flex items-center justify-center overflow-hidden">
                    {pl.coverUrl ? (
                      <img src={pl.coverUrl} alt={pl.name} className="w-full h-full object-cover" />
                    ) : (
                      <Music2 size={32} className="text-[#a7a7a7]" />
                    )}
                  </div>
                  <p className="text-sm font-bold text-white truncate">{pl.name}</p>
                  <p className="text-xs text-[#a7a7a7] mt-1">Playlist</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
