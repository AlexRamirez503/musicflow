import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Play, Pause, ArrowLeft, Shuffle, Loader2, Music2 } from "lucide-react";
import { useParams, Link } from "wouter";
import SongRow from "@/components/SongRow";
import { useMemo } from "react";

function ytToTrack(yt: any): Track {
  return {
    id: yt.id,
    title: yt.title,
    artistId: yt.channelId || "",
    artistName: yt.artist,
    audioUrl: "",
    coverUrl: yt.thumbnailLarge || yt.thumbnail,
    duration: yt.durationSeconds || null,
    source: "youtube",
    videoId: yt.videoId,
  };
}

export default function YouTubeArtist() {
  const params = useParams<{ name: string }>();
  const artistName = decodeURIComponent(params.name ?? "");

  const { data: ytTracks, isLoading } = trpc.youtube.artistTracks.useQuery(
    { artistName },
    { enabled: !!artistName }
  );

  const { play, currentTrack, isPlaying, togglePlay } = usePlayer();
  const tracks = useMemo(() => (ytTracks ?? []).map(ytToTrack), [ytTracks]);
  const isPlayingArtist = tracks.some((t) => t.id === currentTrack?.id);

  // Use the first track's large thumbnail as the hero/banner image
  const heroImage = tracks.length > 0 ? tracks[0].coverUrl : null;

  const handlePlayAll = () => {
    if (isPlayingArtist) {
      togglePlay();
    } else if (tracks.length > 0) {
      play(tracks[0], tracks);
    }
  };

  const handleShuffle = () => {
    if (tracks.length > 0) {
      const shuffled = [...tracks].sort(() => Math.random() - 0.5);
      play(shuffled[0], shuffled);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-[#1db954] animate-spin" />
      </div>
    );
  }

  if (!artistName) {
    return (
      <div className="text-center py-16 text-[#a7a7a7]">
        <p>Artista no encontrado</p>
        <Link href="/" className="text-[#1db954] mt-2 inline-block">Volver al inicio</Link>
      </div>
    );
  }

  return (
    <div className="pb-32">
      {/* Hero banner */}
      <div
        className="relative h-72 md:h-96 flex items-end p-6"
        style={{
          background: heroImage
            ? `linear-gradient(transparent 0%, rgba(0,0,0,0.8) 100%), url(${heroImage}) center/cover no-repeat`
            : "linear-gradient(135deg, #1db954 0%, #121212 100%)",
        }}
      >
        {/* Back button */}
        <Link href="/" className="absolute top-4 left-4 w-10 h-10 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80 transition-colors z-10">
          <ArrowLeft size={20} className="text-white" />
        </Link>

        {/* Artist info overlay */}
        <div className="relative z-10 flex items-end gap-5">
          {/* Artist avatar */}
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-2 border-white/30 shadow-2xl shrink-0 bg-[#282828]">
            {heroImage ? (
              <img src={heroImage} alt={artistName} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Music2 size={40} className="text-[#535353]" />
              </div>
            )}
          </div>
          <div>
            <p className="text-xs text-white/70 uppercase tracking-wider mb-1 font-medium">Artista</p>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-black text-white drop-shadow-lg">{artistName}</h1>
            <p className="text-sm text-white/60 mt-2">
              {tracks.length} {tracks.length === 1 ? "canción" : "canciones"} encontradas
            </p>
          </div>
        </div>
      </div>

      {/* Actions bar */}
      <div className="px-6 py-4 flex items-center gap-4 bg-gradient-to-b from-black/40 to-transparent">
        <button
          onClick={handlePlayAll}
          className="w-14 h-14 rounded-full bg-[#1db954] flex items-center justify-center shadow-xl hover:scale-105 transition-transform hover:bg-[#1ed760]"
        >
          {isPlayingArtist && isPlaying ? (
            <Pause size={28} fill="black" className="text-black" />
          ) : (
            <Play size={28} fill="black" className="text-black ml-1" />
          )}
        </button>
        <button
          onClick={handleShuffle}
          className="w-10 h-10 rounded-full bg-transparent border border-[#535353] flex items-center justify-center hover:border-white transition-colors"
          title="Reproducción aleatoria"
        >
          <Shuffle size={18} className="text-[#a7a7a7] hover:text-white" />
        </button>
      </div>

      {/* Track list */}
      <div className="px-6">
        <h2 className="text-xl font-bold text-white mb-4">Canciones populares</h2>
        {tracks.length > 0 ? (
          <div className="space-y-0.5">
            {tracks.map((track, i) => (
              <SongRow
                key={track.id}
                song={track}
                index={i}
                queue={tracks}
                showCover
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Music2 size={48} className="text-[#535353] mx-auto mb-4" />
            <p className="text-[#a7a7a7] text-sm">No se encontraron canciones de {artistName}.</p>
          </div>
        )}
      </div>
    </div>
  );
}
