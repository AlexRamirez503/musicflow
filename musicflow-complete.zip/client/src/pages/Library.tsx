import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { usePlayer } from "@/contexts/PlayerContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Music2, Disc3, Mic2, ListMusic, Play, Plus } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

type Tab = "songs" | "albums" | "artists" | "playlists";

export default function LibraryPage() {
  const [tab, setTab] = useState<Tab>("songs");
  const { isAuthenticated } = useAuth();
  const { data: library, isLoading } = trpc.library.get.useQuery(undefined, { enabled: isAuthenticated });
  const { data: playlists } = trpc.playlists.myPlaylists.useQuery(undefined, { enabled: isAuthenticated });
  const createPlaylist = trpc.playlists.create.useMutation({
    onSuccess: () => { toast.success("Playlist creada"); },
    onError: () => toast.error("Error al crear playlist"),
  });
  const utils = trpc.useUtils();
  const { play } = usePlayer();

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-24 px-6 text-center">
        <ListMusic size={64} className="text-muted-foreground mb-6 opacity-40" />
        <h2 className="text-2xl font-bold text-foreground mb-3">Tu biblioteca</h2>
        <p className="text-muted-foreground mb-6 max-w-sm">
          Iniciá sesión para ver tus canciones guardadas, álbumes favoritos y playlists.
        </p>
        <a
          href={getLoginUrl()}
          className="bg-primary text-primary-foreground px-8 py-3 rounded-full font-semibold hover:opacity-90 transition-opacity"
        >
          Iniciar sesión
        </a>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "songs", label: "Canciones", icon: <Music2 size={16} /> },
    { id: "albums", label: "Álbumes", icon: <Disc3 size={16} /> },
    { id: "artists", label: "Artistas", icon: <Mic2 size={16} /> },
    { id: "playlists", label: "Playlists", icon: <ListMusic size={16} /> },
  ];

  return (
    <div className="px-6 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-foreground">Tu Biblioteca</h1>
        {tab === "playlists" && (
          <button
            onClick={() => createPlaylist.mutate({ name: `Mi Playlist #${(playlists?.length ?? 0) + 1}` })}
            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            <Plus size={16} /> Nueva playlist
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              tab === t.id
                ? "bg-foreground text-background"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex items-center gap-3 text-muted-foreground py-12">
          <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <span>Cargando biblioteca...</span>
        </div>
      ) : (
        <>
          {/* Songs tab */}
          {tab === "songs" && (
            <div>
              {library?.songs && library.songs.length > 0 ? (
                <div className="space-y-1">
                  {library.songs.map((song: any, i: number) => (
                    <div
                      key={song.id}
                      onClick={() => play(song, library.songs)}
                      className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-accent/50 cursor-pointer transition-colors group"
                    >
                      <span className="w-6 text-xs text-muted-foreground text-right shrink-0">{i + 1}</span>
                      <img
                        src={song.coverUrl ?? `https://picsum.photos/seed/${song.id}/40/40`}
                        alt={song.title}
                        className="w-10 h-10 rounded object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{song.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{song.genre ?? "Canción"}</p>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); play(song, library.songs); }}
                        className="opacity-0 group-hover:opacity-100 w-8 h-8 bg-primary rounded-full flex items-center justify-center transition-all"
                      >
                        <Play size={14} fill="currentColor" className="text-primary-foreground ml-0.5" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={<Music2 size={48} />}
                  title="No tenés canciones guardadas"
                  desc="Guardá canciones tocando el ícono de corazón."
                />
              )}
            </div>
          )}

          {/* Albums tab */}
          {tab === "albums" && (
            <div>
              {library?.albums && library.albums.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {library.albums.map((album: any) => (
                    <Link key={album.id} href={`/album/${album.id}`}>
                      <div className="group bg-card hover:bg-accent/60 rounded-md p-4 transition-all cursor-pointer">
                        <img
                          src={album.coverUrl ?? `https://picsum.photos/seed/al${album.id}/200/200`}
                          alt={album.title}
                          className="w-full aspect-square object-cover rounded mb-3 shadow"
                        />
                        <p className="text-sm font-semibold text-foreground truncate">{album.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">{album.releaseYear ?? "Álbum"}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={<Disc3 size={48} />}
                  title="No tenés álbumes guardados"
                  desc="Guardá álbumes tocando el ícono de corazón en la pantalla del álbum."
                />
              )}
            </div>
          )}

          {/* Artists tab */}
          {tab === "artists" && (
            <div>
              {library?.artists && library.artists.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {library.artists.map((artist: any) => (
                    <Link key={artist.id} href={`/artist/${artist.id}`}>
                      <div className="group flex flex-col items-center p-4 rounded-md hover:bg-accent/60 transition-all cursor-pointer">
                        <img
                          src={artist.imageUrl ?? `https://picsum.photos/seed/a${artist.id}/160/160`}
                          alt={artist.name}
                          className="w-28 h-28 rounded-full object-cover shadow mb-3"
                        />
                        <p className="text-sm font-semibold text-foreground text-center">{artist.name}</p>
                        <p className="text-xs text-muted-foreground mt-1">{artist.genre ?? "Artista"}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={<Mic2 size={48} />}
                  title="No seguís ningún artista"
                  desc="Seguí artistas tocando el ícono de corazón en su perfil."
                />
              )}
            </div>
          )}

          {/* Playlists tab */}
          {tab === "playlists" && (
            <div>
              {playlists && playlists.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {playlists.map((pl: any) => (
                    <Link key={pl.id} href={`/playlist/${pl.id}`}>
                      <div className="group bg-card hover:bg-accent/60 rounded-md p-4 transition-all cursor-pointer">
                        <div className="w-full aspect-square rounded mb-3 bg-secondary flex items-center justify-center overflow-hidden">
                          {pl.coverUrl ? (
                            <img src={pl.coverUrl} alt={pl.name} className="w-full h-full object-cover" />
                          ) : (
                            <Music2 size={32} className="text-muted-foreground" />
                          )}
                        </div>
                        <p className="text-sm font-semibold text-foreground truncate">{pl.name}</p>
                        <p className="text-xs text-muted-foreground mt-1">Playlist</p>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={<ListMusic size={48} />}
                  title="No tenés playlists"
                  desc="Creá tu primera playlist con el botón de arriba."
                />
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function EmptyState({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground text-center">
      <div className="opacity-30 mb-4">{icon}</div>
      <p className="text-lg font-semibold text-foreground mb-2">{title}</p>
      <p className="text-sm max-w-xs">{desc}</p>
    </div>
  );
}
