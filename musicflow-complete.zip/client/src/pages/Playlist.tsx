import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePlayer } from "@/contexts/PlayerContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { Play, Shuffle, Pencil, Trash2, Music2, Plus, X } from "lucide-react";
import SongRow from "@/components/SongRow";
import { toast } from "sonner";

export default function PlaylistPage() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [showAddSong, setShowAddSong] = useState(false);
  const [songSearch, setSongSearch] = useState("");

  const { isAuthenticated } = useAuth();
  const { play } = usePlayer();
  const [, navigate] = useLocation();

  const { data: playlist, isLoading, refetch } = trpc.playlists.byId.useQuery({ id }, { enabled: id > 0 });
  const { data: songs, refetch: refetchSongs } = trpc.playlists.songs.useQuery({ playlistId: id }, { enabled: id > 0 });
  const { data: allSongs } = trpc.songs.list.useQuery();

  const updatePlaylist = trpc.playlists.update.useMutation({
    onSuccess: () => { toast.success("Playlist actualizada"); setEditing(false); refetch(); },
    onError: () => toast.error("Error al actualizar"),
  });
  const deletePlaylist = trpc.playlists.delete.useMutation({
    onSuccess: () => { toast.success("Playlist eliminada"); navigate("/library"); },
    onError: () => toast.error("Error al eliminar"),
  });
  const addSong = trpc.playlists.addSong.useMutation({
    onSuccess: () => { toast.success("Canción agregada"); refetchSongs(); },
    onError: () => toast.error("Error al agregar"),
  });
  const removeSong = trpc.playlists.removeSong.useMutation({
    onSuccess: () => { toast.success("Canción eliminada"); refetchSongs(); },
    onError: () => toast.error("Error al eliminar"),
  });

  const queue = (songs ?? []).map((s: any) => ({ ...s }));

  const filteredSongs = allSongs?.filter((s: any) =>
    s.title.toLowerCase().includes(songSearch.toLowerCase())
  ) ?? [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!playlist) return <div className="p-8 text-muted-foreground">Playlist no encontrada.</div>;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-end gap-6 px-6 pt-8 pb-6 bg-gradient-to-b from-[#2a1a3e] to-background">
        <div className="w-48 h-48 rounded shadow-2xl bg-secondary flex items-center justify-center overflow-hidden shrink-0">
          {playlist.coverUrl ? (
            <img src={playlist.coverUrl} alt={playlist.name} className="w-full h-full object-cover" />
          ) : (
            <Music2 size={64} className="text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground uppercase tracking-widest mb-2">Playlist</p>
          {editing ? (
            <div className="flex items-center gap-2 mb-4">
              <input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="text-2xl font-black bg-transparent border-b-2 border-primary text-foreground focus:outline-none flex-1"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") updatePlaylist.mutate({ id, name: editName });
                  if (e.key === "Escape") setEditing(false);
                }}
              />
              <button onClick={() => updatePlaylist.mutate({ id, name: editName })} className="text-primary text-sm font-semibold">Guardar</button>
              <button onClick={() => setEditing(false)} className="text-muted-foreground text-sm">Cancelar</button>
            </div>
          ) : (
            <h1 className="text-3xl md:text-5xl font-black text-foreground mb-4 leading-tight">{playlist.name}</h1>
          )}
          {playlist.description && (
            <p className="text-sm text-muted-foreground mb-2">{playlist.description}</p>
          )}
          <p className="text-sm text-muted-foreground">{songs?.length ?? 0} canciones</p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-4 px-6 py-4">
        <button
          onClick={() => queue.length > 0 && play(queue[0], queue)}
          className="w-14 h-14 bg-primary rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
        >
          <Play size={24} fill="currentColor" className="text-primary-foreground ml-1" />
        </button>
        <button
          onClick={() => {
            if (queue.length > 0) {
              const shuffled = [...queue].sort(() => Math.random() - 0.5);
              play(shuffled[0], shuffled);
            }
          }}
          className="w-12 h-12 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <Shuffle size={20} />
        </button>
        {isAuthenticated && (
          <>
            <button
              onClick={() => { setEditing(true); setEditName(playlist.name); }}
              className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
              title="Editar"
            >
              <Pencil size={16} />
            </button>
            <button
              onClick={() => { if (confirm("¿Eliminar esta playlist?")) deletePlaylist.mutate({ id }); }}
              className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors"
              title="Eliminar"
            >
              <Trash2 size={16} />
            </button>
            <button
              onClick={() => setShowAddSong(!showAddSong)}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-border text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Plus size={16} /> Agregar canciones
            </button>
          </>
        )}
      </div>

      {/* Add song panel */}
      {showAddSong && (
        <div className="mx-6 mb-6 bg-card rounded-lg p-4 border border-border">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Agregar canciones</h3>
            <button onClick={() => setShowAddSong(false)} className="text-muted-foreground hover:text-foreground">
              <X size={16} />
            </button>
          </div>
          <input
            type="text"
            value={songSearch}
            onChange={(e) => setSongSearch(e.target.value)}
            placeholder="Buscar canción..."
            className="w-full px-3 py-2 rounded-md bg-secondary border border-border text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary mb-3"
          />
          <div className="space-y-1 max-h-48 overflow-y-auto">
            {filteredSongs.slice(0, 20).map((song: any) => {
              const alreadyAdded = songs?.some((s: any) => s.id === song.id);
              return (
                <div key={song.id} className="flex items-center gap-3 px-2 py-1.5 rounded hover:bg-accent/50 transition-colors">
                  <img
                    src={song.coverUrl ?? `https://picsum.photos/seed/${song.id}/32/32`}
                    alt={song.title}
                    className="w-8 h-8 rounded object-cover shrink-0"
                  />
                  <span className="text-sm text-foreground flex-1 truncate">{song.title}</span>
                  <button
                    onClick={() => !alreadyAdded && addSong.mutate({ playlistId: id, songId: song.id })}
                    disabled={alreadyAdded}
                    className={`text-xs px-3 py-1 rounded-full font-medium transition-colors ${
                      alreadyAdded
                        ? "bg-secondary text-muted-foreground cursor-not-allowed"
                        : "bg-primary text-primary-foreground hover:opacity-90"
                    }`}
                  >
                    {alreadyAdded ? "Agregada" : "Agregar"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Song list */}
      <div className="px-6">
        {songs && songs.length > 0 ? (
          <div className="space-y-1">
            {songs.map((song: any, i: number) => (
              <div key={song.id} className="group flex items-center">
                <div className="flex-1 min-w-0">
                  <SongRow song={song} index={i} queue={queue} showCover />
                </div>
                {isAuthenticated && (
                  <button
                    onClick={() => removeSong.mutate({ playlistId: id, songId: song.id })}
                    className="opacity-0 group-hover:opacity-100 w-8 h-8 flex items-center justify-center text-muted-foreground hover:text-destructive transition-all shrink-0 mr-2"
                    title="Quitar de playlist"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground text-center">
            <Music2 size={48} className="opacity-30 mb-4" />
            <p className="text-lg font-semibold text-foreground mb-2">Esta playlist está vacía</p>
            <p className="text-sm">Agregá canciones usando el botón de arriba.</p>
          </div>
        )}
      </div>
    </div>
  );
}
