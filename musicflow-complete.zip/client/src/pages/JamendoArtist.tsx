import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Play, Pause, ArrowLeft } from "lucide-react";
import { useParams, Link } from "wouter";
import SongRow from "@/components/SongRow";

function mapJamendoTrack(t: any): Track {
  return {
    id: t.id,
    title: t.name,
    artistId: t.artist_id,
    artistName: t.artist_name,
    albumId: t.album_id,
    albumName: t.album_name,
    audioUrl: t.audio,
    coverUrl: t.album_image || t.image,
    duration: t.duration,
    source: "jamendo",
  };
}

export default function JamendoArtist() {
  const params = useParams<{ id: string }>();
  const artistId = params.id ?? "";

  const { data: artist, isLoading: loadingArtist } = trpc.jamendo.artist.useQuery(
    { artistId },
    { enabled: !!artistId }
  );
  const { data: tracks, isLoading: loadingTracks } = trpc.jamendo.artistTracks.useQuery(
    { artistId, limit: 20 },
    { enabled: !!artistId }
  );

  const { play, currentTrack, isPlaying, togglePlay } = usePlayer();
  const mappedTracks = (tracks ?? []).map(mapJamendoTrack);
  const isPlayingArtist = mappedTracks.some((t) => t.id === currentTrack?.id);

  const handlePlayAll = () => {
    if (isPlayingArtist) {
      togglePlay();
    } else if (mappedTracks.length > 0) {
      play(mappedTracks[0], mappedTracks);
    }
  };

  if (loadingArtist) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-[#1db954] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!artist) {
    return (
      <div className="text-center py-16 text-[#a7a7a7]">
        <p>Artista no encontrado</p>
        <Link href="/" className="text-[#1db954] mt-2 inline-block">Volver al inicio</Link>
      </div>
    );
  }

  return (
    <div className="pb-32">
      {/* Hero */}
      <div
        className="relative h-72 md:h-80 flex items-end p-6"
        style={{
          background: `linear-gradient(transparent 0%, rgba(0,0,0,0.7) 100%), url(${artist.image || `https://picsum.photos/seed/artist-${artist.id}/800/400`}) center/cover`,
        }}
      >
        <Link href="/" className="absolute top-4 left-4 w-8 h-8 rounded-full bg-black/50 flex items-center justify-center">
          <ArrowLeft size={18} className="text-white" />
        </Link>
        <div>
          <p className="text-xs text-white/70 uppercase tracking-wider mb-1">Artista</p>
          <h1 className="text-4xl md:text-6xl font-black text-white">{artist.name}</h1>
        </div>
      </div>

      {/* Actions */}
      <div className="px-6 py-4 flex items-center gap-4">
        <button
          onClick={handlePlayAll}
          className="w-14 h-14 rounded-full bg-[#1db954] flex items-center justify-center shadow-xl hover:scale-105 transition-transform"
        >
          {isPlayingArtist && isPlaying ? (
            <Pause size={28} fill="black" className="text-black" />
          ) : (
            <Play size={28} fill="black" className="text-black ml-1" />
          )}
        </button>
      </div>

      {/* Popular tracks */}
      <div className="px-6">
        <h2 className="text-xl font-bold text-white mb-4">Canciones populares</h2>
        {loadingTracks ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="animate-pulse flex items-center gap-3 px-4 py-2">
                <div className="w-8 h-4 bg-[#282828] rounded" />
                <div className="w-10 h-10 bg-[#282828] rounded" />
                <div className="flex-1">
                  <div className="h-3 bg-[#282828] rounded w-1/3 mb-2" />
                  <div className="h-3 bg-[#282828] rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : mappedTracks.length > 0 ? (
          <div className="space-y-0.5">
            {mappedTracks.map((track, i) => (
              <SongRow
                key={track.id}
                song={{ ...track, albumTitle: track.albumName }}
                index={i}
                queue={mappedTracks}
                showAlbum
              />
            ))}
          </div>
        ) : (
          <p className="text-[#a7a7a7] text-sm">No se encontraron canciones de este artista.</p>
        )}
      </div>
    </div>
  );
}
