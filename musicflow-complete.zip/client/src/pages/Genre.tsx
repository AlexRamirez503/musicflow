import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePlayer, Track } from "@/contexts/PlayerContext";
import { Play, Pause, Music2, ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useMemo } from "react";

function ytToTrack(yt: any): Track {
  return {
    id: yt.id,
    title: yt.title,
    artistId: yt.channelId || "",
    artistName: yt.artist,
    audioUrl: "",
    coverUrl: yt.thumbnailLarge || yt.thumbnail,
    duration: yt.durationSeconds || null,
    source: "youtube",
    videoId: yt.videoId,
  };
}

export default function GenrePage() {
  const params = useParams<{ id: string }>();
  const genreId = params.id || "";

  const { data: genresData } = trpc.youtube.genres.useQuery();
  const { data: tracksData, isLoading } = trpc.youtube.genre.useQuery(
    { genre: genreId },
    { enabled: !!genreId }
  );

  const { play, currentTrack, isPlaying, togglePlay } = usePlayer();

  const genre = useMemo(
    () => (genresData || []).find((g: any) => g.id === genreId),
    [genresData, genreId]
  );
  const tracks = useMemo(() => (tracksData || []).map(ytToTrack), [tracksData]);

  return (
    <div className="pb-32">
      {/* Header */}
      <div
        className="relative px-4 md:px-6 pt-6 pb-8"
        style={{
          background: genre
            ? `linear-gradient(to bottom, ${genre.color}88, #121212)`
            : "linear-gradient(to bottom, #282828, #121212)",
        }}
      >
        <Link href="/">
          <button className="w-8 h-8 rounded-full bg-black/40 flex items-center justify-center mb-4 hover:bg-black/60 transition-colors">
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
        </Link>
        <div className="flex items-center gap-4">
          {genre && <span className="text-5xl">{genre.icon}</span>}
          <div>
            <p className="text-xs text-white/70 uppercase tracking-wider font-medium">Género</p>
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              {genre?.name || genreId}
            </h1>
          </div>
        </div>
      </div>

      {/* Play all button */}
      {tracks.length > 0 && (
        <div className="px-4 md:px-6 py-4 flex items-center gap-4">
          <button
            onClick={() => play(tracks[0], tracks)}
            className="w-14 h-14 rounded-full bg-[#1db954] flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
          >
            <Play className="w-6 h-6 text-black ml-0.5" fill="black" />
          </button>
        </div>
      )}

      {/* Tracks list */}
      <div className="px-4 md:px-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 text-[#1db954] animate-spin" />
          </div>
        ) : tracks.length > 0 ? (
          <div className="space-y-1">
            {tracks.map((track, i) => {
              const isActive = currentTrack?.id === track.id;
              return (
                <div
                  key={track.id}
                  onClick={() => (isActive ? togglePlay() : play(track, tracks))}
                  className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[#ffffff12] cursor-pointer transition-colors group"
                >
                  <span className="w-5 text-center text-sm text-[#a7a7a7] group-hover:hidden">
                    {i + 1}
                  </span>
                  <span className="w-5 text-center hidden group-hover:block">
                    {isActive && isPlaying ? (
                      <Pause size={14} className="text-white" />
                    ) : (
                      <Play size={14} className="text-white" fill="white" />
                    )}
                  </span>
                  <img
                    src={track.coverUrl || ""}
                    alt={track.title}
                    className="w-10 h-10 rounded object-cover shrink-0 bg-[#282828]"
                    loading="lazy"
                  />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${isActive ? "text-[#1db954]" : "text-white"}`}>
                      {track.title}
                    </p>
                    <p className="text-xs text-[#a7a7a7] truncate">{track.artistName}</p>
                  </div>
                  {track.duration ? (
                    <span className="text-xs text-[#a7a7a7]">
                      {Math.floor(track.duration / 60)}:{String(Math.floor(track.duration % 60)).padStart(2, "0")}
                    </span>
                  ) : null}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 text-[#a7a7a7]">
            <Music2 size={48} className="mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium text-white">No se encontraron canciones</p>
          </div>
        )}
      </div>
    </div>
  );
}
