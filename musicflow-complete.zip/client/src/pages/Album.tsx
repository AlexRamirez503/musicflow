import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePlayer } from "@/contexts/PlayerContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { Play, Heart, Shuffle, Clock } from "lucide-react";
import SongRow from "@/components/SongRow";

export default function AlbumPage() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");

  const { data: album, isLoading } = trpc.albums.byId.useQuery({ id }, { enabled: id > 0 });
  const { data: songs } = trpc.albums.songs.useQuery({ albumId: id }, { enabled: id > 0 });
  const { data: artist } = trpc.artists.byId.useQuery(
    { id: album?.artistId ?? 0 },
    { enabled: !!album?.artistId }
  );
  const { isAuthenticated } = useAuth();
  const toggleLibrary = trpc.library.toggle.useMutation();
  const { data: isSaved } = trpc.library.check.useQuery(
    { type: "album", itemId: id },
    { enabled: isAuthenticated && id > 0 }
  );

  const { play } = usePlayer();

  const queue = (songs ?? []).map((s: any) => ({
    ...s,
    artistName: artist?.name,
    albumId: s.albumId ?? undefined,
  }));

  const totalDuration = (songs ?? []).reduce((acc: number, s: any) => acc + (s.duration ?? 0), 0);
  const formatTotal = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return h > 0 ? `${h} h ${m} min` : `${m} min`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!album) return <div className="p-8 text-muted-foreground">Álbum no encontrado.</div>;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-end gap-6 px-6 pt-8 pb-6 bg-gradient-to-b from-[#1a1a3e] to-background">
        <img
          src={album.coverUrl ?? `https://picsum.photos/seed/al${album.id}/240/240`}
          alt={album.title}
          className="w-48 h-48 rounded shadow-2xl object-cover shrink-0"
        />
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground uppercase tracking-widest mb-2">Álbum</p>
          <h1 className="text-3xl md:text-5xl font-black text-foreground mb-4 leading-tight">{album.title}</h1>
          <div className="flex items-center gap-2 flex-wrap text-sm text-muted-foreground">
            {artist && (
              <Link href={`/artist/${artist.id}`}>
                <span className="font-semibold text-foreground hover:underline cursor-pointer">{artist.name}</span>
              </Link>
            )}
            {album.releaseYear && <><span>·</span><span>{album.releaseYear}</span></>}
            {songs && <><span>·</span><span>{songs.length} canciones</span></>}
            {totalDuration > 0 && <><span>·</span><span>{formatTotal(totalDuration)}</span></>}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-4 px-6 py-4">
        <button
          onClick={() => queue.length > 0 && play(queue[0], queue)}
          className="w-14 h-14 bg-primary rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
        >
          <Play size={24} fill="currentColor" className="text-primary-foreground ml-1" />
        </button>
        <button
          onClick={() => {
            if (queue.length > 0) {
              const shuffled = [...queue].sort(() => Math.random() - 0.5);
              play(shuffled[0], shuffled);
            }
          }}
          className="w-12 h-12 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <Shuffle size={20} />
        </button>
        {isAuthenticated && (
          <button
            onClick={() => toggleLibrary.mutate({ type: "album", itemId: id })}
            className={`transition-colors ${isSaved ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Heart size={24} fill={isSaved ? "currentColor" : "none"} />
          </button>
        )}
      </div>

      {/* Song list */}
      <div className="px-6">
        {/* Header row */}
        <div className="flex items-center gap-3 px-4 py-2 text-xs text-muted-foreground uppercase tracking-wider border-b border-border mb-2">
          <span className="w-8 text-center">#</span>
          <span className="flex-1">Título</span>
          <span className="flex items-center gap-1"><Clock size={12} /></span>
        </div>

        {songs && songs.length > 0 ? (
          <div className="space-y-1">
            {songs.map((song: any, i: number) => (
              <SongRow
                key={song.id}
                song={{ ...song, artistName: artist?.name, albumId: song.albumId ?? undefined }}
                index={i}
                queue={queue}
                showCover={false}
              />
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm py-8 text-center">Este álbum no tiene canciones aún.</p>
        )}
      </div>
    </div>
  );
}
