import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePlayer } from "@/contexts/PlayerContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { Play, Heart, Shuffle } from "lucide-react";
import SongRow from "@/components/SongRow";

export default function ArtistPage() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");

  const { data: artist, isLoading } = trpc.artists.byId.useQuery({ id }, { enabled: id > 0 });
  const { data: songs } = trpc.artists.songs.useQuery({ artistId: id }, { enabled: id > 0 });
  const { data: albums } = trpc.artists.albums.useQuery({ artistId: id }, { enabled: id > 0 });
  const { isAuthenticated } = useAuth();
  const toggleLibrary = trpc.library.toggle.useMutation();
  const { data: isSaved } = trpc.library.check.useQuery(
    { type: "artist", itemId: id },
    { enabled: isAuthenticated && id > 0 }
  );

  const { play } = usePlayer();

  const queue = (songs ?? []).map((s: any) => ({ ...s, artistName: artist?.name }));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!artist) return <div className="p-8 text-muted-foreground">Artista no encontrado.</div>;

  return (
    <div className="pb-8">
      {/* Hero */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img
          src={artist.imageUrl ?? `https://picsum.photos/seed/a${artist.id}/800/400`}
          alt={artist.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        <div className="absolute bottom-6 left-6">
          <p className="text-xs font-semibold text-foreground uppercase tracking-widest mb-1">Artista</p>
          <h1 className="text-4xl md:text-6xl font-black text-foreground">{artist.name}</h1>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-4 px-6 py-6">
        <button
          onClick={() => songs && songs.length > 0 && play({ ...songs[0], artistName: artist.name }, queue)}
          className="w-14 h-14 bg-primary rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
        >
          <Play size={24} fill="currentColor" className="text-primary-foreground ml-1" />
        </button>
        <button
          onClick={() => {
            if (songs && songs.length > 0) {
              const shuffled = [...queue].sort(() => Math.random() - 0.5);
              play(shuffled[0], shuffled);
            }
          }}
          className="w-12 h-12 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <Shuffle size={20} />
        </button>
        {isAuthenticated && (
          <button
            onClick={() => toggleLibrary.mutate({ type: "artist", itemId: id })}
            className={`transition-colors ${isSaved ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Heart size={24} fill={isSaved ? "currentColor" : "none"} />
          </button>
        )}
      </div>

      <div className="px-6 space-y-8">
        {/* Bio */}
        {artist.bio && (
          <p className="text-muted-foreground text-sm max-w-2xl">{artist.bio}</p>
        )}

        {/* Popular songs */}
        {songs && songs.length > 0 && (
          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">Canciones populares</h2>
            <div className="space-y-1">
              {songs.map((song: any, i: number) => (
                <SongRow
                  key={song.id}
                  song={{ ...song, artistName: artist.name }}
                  index={i}
                  queue={queue}
                  showCover
                />
              ))}
            </div>
          </section>
        )}

        {/* Albums */}
        {albums && albums.length > 0 && (
          <section>
            <h2 className="text-xl font-bold text-foreground mb-4">Discografía</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {albums.map((album: any) => (
                <Link key={album.id} href={`/album/${album.id}`}>
                  <div className="group bg-card hover:bg-accent/60 rounded-md p-4 transition-all cursor-pointer">
                    <img
                      src={album.coverUrl ?? `https://picsum.photos/seed/al${album.id}/200/200`}
                      alt={album.title}
                      className="w-full aspect-square object-cover rounded mb-3 shadow"
                    />
                    <p className="text-sm font-semibold text-foreground truncate">{album.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{album.releaseYear ?? "Álbum"}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
